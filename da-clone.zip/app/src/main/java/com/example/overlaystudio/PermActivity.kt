package com.example.overlaystudio

import android.app.Activity
import android.os.Bundle

class PermActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); requestPermissions(arrayOf("android.permission.RECORD_AUDIO"), 1) }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(c, p, r); finish() }
}
