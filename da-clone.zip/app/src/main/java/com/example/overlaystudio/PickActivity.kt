package com.example.overlaystudio

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class PickActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"; i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, 1)
    }
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        val u = d?.data
        if (c == RESULT_OK && u != null) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            OverlayService.onPicked?.invoke(u.toString())
        } else OverlayService.onPicked?.invoke("")
        finish()
    }
}
