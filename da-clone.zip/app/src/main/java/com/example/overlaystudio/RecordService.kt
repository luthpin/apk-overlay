package com.example.overlaystudio

import android.app.*
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.MediaStore
import android.widget.Toast
import java.io.File
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*

class RecordService : Service() {
    companion object { @Volatile var running = false; @Volatile var lastFile = "" }
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private var mux: MediaMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private val lock = Any()
    private var vTrack = -1; private var aTrack = -1; private var started = false; private var wantAudio = false
    @Volatile private var alive = false
    @Volatile private var vBase = -1L
    private val threads = mutableListOf<Thread>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null || i.action == "stop") { finishRec(); return START_NOT_STICKY }
        if (alive) return START_NOT_STICKY
        val micOk = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("rec", "Rekam layar", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getService(this, 0, Intent(this, RecordService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "rec").setContentTitle("Streamix merekam layar").setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", pi).build()).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or (if (micOk) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0))
        else startForeground(2, n)
        try { begin(i, micOk) } catch (e: Exception) {
            Toast.makeText(this, "Gagal mulai rekam: " + e.message, Toast.LENGTH_LONG).show(); alive = true; finishRec()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun begin(i: Intent, micOk: Boolean) {
        val w = i.getIntExtra("w", 720); val h = i.getIntExtra("h", 1280); val dpi = i.getIntExtra("dpi", 320)
        val fps = i.getIntExtra("fps", 30); val br = i.getIntExtra("br", 2500) * 1000
        val mg = i.getFloatExtra("mg", 1f); val gg = i.getFloatExtra("gg", 1f)
        val data = i.getParcelableExtra<Intent>("data")!!
        val pr = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data); proj = pr
        pr.registerCallback(object : MediaProjection.Callback() { override fun onStop() { finishRec() } }, Handler(Looper.getMainLooper()))
        val name = "Streamix_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues(); cv.put(MediaStore.Video.Media.DISPLAY_NAME, name); cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); cv.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Streamix")
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            pfd = contentResolver.openFileDescriptor(uri, "w")
            mux = MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); lastFile = "Movies/Streamix/$name"
        } else {
            val f = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), name)
            mux = MediaMuxer(f.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); lastFile = f.absolutePath
        }
        val vf = MediaFormat.createVideoFormat("video/avc", w, h)
        vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, android.media.MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        vf.setInteger(MediaFormat.KEY_BIT_RATE, br); vf.setInteger(MediaFormat.KEY_FRAME_RATE, fps); vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        val ve = MediaCodec.createEncoderByType("video/avc"); ve.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surf = ve.createInputSurface(); ve.start(); venc = ve
        vd = pr.createVirtualDisplay("streamix", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surf, null, null)
        alive = true; running = true; wantAudio = micOk
        threads.add(Thread { drainVideo(ve) }.also { it.start() })
        if (micOk) threads.add(Thread { audioLoop(pr, mg, gg) }.also { it.start() })
    }

    private fun tryStart() {
        if (!started && vTrack >= 0 && (!wantAudio || aTrack >= 0)) {
            mux!!.start(); started = true
            try { val b = Bundle(); b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0); venc?.setParameters(b) } catch (e: Exception) {}
        }
    }

    private fun drainVideo(ve: MediaCodec) {
        val bi = MediaCodec.BufferInfo()
        try {
            while (alive) {
                val oi = ve.dequeueOutputBuffer(bi, 10000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) synchronized(lock) { vTrack = mux!!.addTrack(ve.outputFormat); tryStart() }
                else if (oi >= 0) {
                    val ob = ve.getOutputBuffer(oi)!!
                    if (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bi.size = 0
                    if (bi.size > 0) {
                        if (vBase < 0) vBase = bi.presentationTimeUs
                        bi.presentationTimeUs = bi.presentationTimeUs - vBase
                        if (started) synchronized(lock) { mux!!.writeSampleData(vTrack, ob, bi) }
                    }
                    ve.releaseOutputBuffer(oi, false)
                }
            }
        } catch (e: Exception) {}
    }

    private fun drainAudio(ae: MediaCodec, bi: MediaCodec.BufferInfo) {
        while (true) {
            val oi = ae.dequeueOutputBuffer(bi, 0)
            if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) synchronized(lock) { aTrack = mux!!.addTrack(ae.outputFormat); tryStart() }
            else if (oi >= 0) {
                val ob = ae.getOutputBuffer(oi)!!
                if (bi.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) bi.size = 0
                if (bi.size > 0 && started) synchronized(lock) { mux!!.writeSampleData(aTrack, ob, bi) }
                ae.releaseOutputBuffer(oi, false)
            } else break
        }
    }

    private fun audioLoop(pr: MediaProjection, mg: Float, gg: Float) {
        val sr = 44100; val bs = maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT), 8192)
        var mic: AudioRecord? = null; var game: AudioRecord? = null
        try {
            mic = AudioRecord(MediaRecorder.AudioSource.MIC, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bs)
            if (Build.VERSION.SDK_INT >= 29) {
                try {
                    val cfg = AudioPlaybackCaptureConfiguration.Builder(pr).addMatchingUsage(AudioAttributes.USAGE_GAME).addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
                    game = AudioRecord.Builder().setAudioPlaybackCaptureConfig(cfg)
                        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build())
                        .setBufferSizeInBytes(bs).build()
                } catch (e: Exception) { game = null }
            }
            val af = MediaFormat.createAudioFormat("audio/mp4a-latm", sr, 1)
            af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC); af.setInteger(MediaFormat.KEY_BIT_RATE, 128000); af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            val ae = MediaCodec.createEncoderByType("audio/mp4a-latm"); ae.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); ae.start(); aenc = ae
            mic.startRecording(); game?.startRecording()
            val n = 1024; val b1 = ShortArray(n); val b2 = ShortArray(n); val mix = ShortArray(n); val bi = MediaCodec.BufferInfo()
            while (alive) {
                var r1 = 0; while (r1 < n && alive) { val k = mic.read(b1, r1, n - r1); if (k <= 0) break; r1 += k }
                var r2 = 0; if (game != null) while (r2 < n && alive) { val k = game.read(b2, r2, n - r2); if (k <= 0) break; r2 += k }
                for (j in 0 until n) {
                    val a = if (j < r1) b1[j] * mg else 0f; val c = if (game != null && j < r2) b2[j] * gg else 0f
                    mix[j] = (a + c).coerceIn(-32768f, 32767f).toInt().toShort()
                }
                if (vBase >= 0) {
                    val ii = ae.dequeueInputBuffer(10000)
                    if (ii >= 0) { val ib = ae.getInputBuffer(ii)!!; ib.clear(); ib.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(mix); ae.queueInputBuffer(ii, 0, n * 2, System.nanoTime() / 1000 - vBase, 0) }
                }
                drainAudio(ae, bi)
            }
        } catch (e: Exception) {
        } finally { try { mic?.stop(); mic?.release(); game?.stop(); game?.release() } catch (e: Exception) {} }
    }

    private fun finishRec() {
        if (!alive && !running) { stopSelf(); return }
        alive = false; running = false
        Thread {
            threads.forEach { try { it.join(1500) } catch (e: Exception) {} }; threads.clear()
            try { vd?.release() } catch (e: Exception) {}
            try { proj?.stop() } catch (e: Exception) {}
            try { venc?.stop(); venc?.release() } catch (e: Exception) {}
            try { aenc?.stop(); aenc?.release() } catch (e: Exception) {}
            try { if (started) mux?.stop(); mux?.release() } catch (e: Exception) {}
            try { pfd?.close() } catch (e: Exception) {}
            started = false; vTrack = -1; aTrack = -1; vBase = -1L; venc = null; aenc = null; mux = null; vd = null; proj = null
            Handler(Looper.getMainLooper()).post { stopForeground(true); stopSelf() }
        }.start()
    }

    override fun onDestroy() { alive = false; running = false; super.onDestroy() }
}
