package com.example.overlaystudio

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class OverlayService : Service() {
    companion object { var onPicked: ((String) -> Unit)? = null }

    private lateinit var wm: WindowManager
    private val items = mutableListOf<JSONObject>()
    private val views = mutableMapOf<String, FrameLayout>()
    private val params = mutableMapOf<String, LP>()
    private var edit = false
    private var bubble: TextView? = null
    private var bubbleP: LP? = null
    private var panel: View? = null
    private var form: View? = null
    private val d: Float get() = resources.displayMetrics.density
    private val orange = Color.parseColor("#FF8A00")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "ov").setContentTitle("Overlay aktif").setSmallIcon(android.R.drawable.ic_menu_edit).build())
        val arr = JSONArray(getSharedPreferences("p", 0).getString("items", "[]"))
        for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
        items.forEach { addWidget(it) }
        makeBubble()
    }

    private fun lp(w: Int, h: Int, touch: Boolean, focus: Boolean = false): LP {
        var f = LP.FLAG_LAYOUT_NO_LIMITS
        if (!touch) f = f or LP.FLAG_NOT_TOUCHABLE
        if (!focus) f = f or LP.FLAG_NOT_FOCUSABLE
        val p = LP(w, h, LP.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }

    private fun tv(s: String): TextView { val t = TextView(this); t.text = s; t.setTextColor(Color.WHITE); return t }

    private fun btn(s: String, c: Int): TextView {
        val t = tv(s); t.gravity = Gravity.CENTER; t.textSize = 18f
        val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(c); t.background = g
        return t
    }

    private fun card(): LinearLayout {
        val b = LinearLayout(this); b.orientation = LinearLayout.VERTICAL; b.setPadding(40, 30, 40, 30)
        val g = GradientDrawable(); g.setColor(Color.parseColor("#F2202020")); g.cornerRadius = 30f; b.background = g
        return b
    }

    private fun drag(v: View, win: View, p: LP, onClick: (() -> Unit)?, onEnd: (() -> Unit)?) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    if (moved) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(win, p) }
                }
                MotionEvent.ACTION_UP -> if (moved) onEnd?.invoke() else onClick?.invoke()
            }
            true
        }
    }

    private fun save() {
        getSharedPreferences("p", 0).edit().putString("items", JSONArray(items).toString()).apply()
    }

    private fun newItem(t: String, u: String): JSONObject {
        val web = t == "web"
        return JSONObject().put("id", System.currentTimeMillis().toString()).put("t", t)
            .put("n", if (web) "Web-source" else "Picture").put("u", u)
            .put("w", if (web) 450 else 400).put("h", if (web) 338 else 300)
            .put("a", 100).put("x", 50).put("y", 300)
    }

    private fun makeBubble() {
        val s = (56 * d).toInt()
        val b = btn("+", orange); b.textSize = 26f
        val p = lp(s, s, true); p.x = 0; p.y = 300
        drag(b, b, p, { setEdit(!edit) }, null)
        wm.addView(b, p); bubble = b; bubbleP = p
    }

    private fun addWidget(o: JSONObject) {
        val id = o.getString("id")
        val root = FrameLayout(this)
        val content: View
        if (o.getString("t") == "web") {
            val w = WebView(this)
            w.setBackgroundColor(0)
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.settings.mediaPlaybackRequiresUserGesture = false
            w.webViewClient = WebViewClient()
            w.loadUrl(o.getString("u"))
            content = w
        } else {
            val iv = ImageView(this); iv.setImageURI(Uri.parse(o.getString("u"))); content = iv
        }
        content.alpha = o.getInt("a") / 100f
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val p = lp(o.getInt("w"), o.getInt("h"), edit)
        p.x = o.getInt("x"); p.y = o.getInt("y")

        val ctl = FrameLayout(this)
        ctl.visibility = if (edit) View.VISIBLE else View.GONE
        val border = View(this)
        val g = GradientDrawable(); g.setColor(0x33000000); g.setStroke(3, Color.WHITE); border.background = g
        ctl.addView(border)
        val shield = View(this)
        ctl.addView(shield)
        drag(shield, root, p, null) { o.put("x", p.x).put("y", p.y); save() }
        val sz = (36 * d).toInt()
        val del = btn("✕", orange); del.setOnClickListener { removeItem(id) }
        val gear = btn("⚙", Color.DKGRAY); gear.setOnClickListener { showForm(o, false) }
        ctl.addView(del, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.START))
        ctl.addView(gear, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END))
        root.addView(ctl)

        wm.addView(root, p)
        views[id] = root; params[id] = p
        bubble?.let { wm.removeView(it); wm.addView(it, bubbleP) }
    }

    private fun killView(id: String) {
        val v = views.remove(id) ?: return
        params.remove(id)
        wm.removeView(v)
        (v.getChildAt(0) as? WebView)?.destroy()
    }

    private fun removeItem(id: String) {
        killView(id); items.removeAll { it.getString("id") == id }; save()
    }

    private fun setEdit(on: Boolean) {
        edit = on
        bubble?.text = if (on) "✕" else "+"
        for ((id, v) in views) {
            val p = params[id]!!
            p.flags = if (on) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
            v.getChildAt(1).visibility = if (on) View.VISIBLE else View.GONE
            wm.updateViewLayout(v, p)
        }
        if (on) showPanel() else { panel?.let { wm.removeView(it) }; panel = null; closeForm() }
    }

    private fun showPanel() {
        val row = LinearLayout(this); row.gravity = Gravity.CENTER; row.setPadding(0, 20, 0, 20)
        fun opt(label: String, icon: String, color: Int, act: () -> Unit) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER; c.setPadding(40, 0, 40, 0)
            c.addView(btn(icon, color), LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt()))
            c.addView(tv(label))
            c.setOnClickListener { act() }
            row.addView(c)
        }
        opt("Web-source", "🌐", Color.parseColor("#4A90D9")) { showForm(newItem("web", ""), true) }
        opt("Picture", "🖼", Color.parseColor("#8E6CCF")) {
            onPicked = { u -> Handler(Looper.getMainLooper()).post { showForm(newItem("pic", u), true) } }
            startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val box = card()
        val title = tv("Add widget"); title.textSize = 18f; title.gravity = Gravity.CENTER
        box.addView(title); box.addView(row)
        val p = lp(-1, -2, true); p.gravity = Gravity.BOTTOM
        wm.addView(box, p); panel = box
    }

    private fun closeForm() { form?.let { wm.removeView(it) }; form = null }

    private fun et(h: String, v: String, num: Boolean): EditText {
        val e = EditText(this); e.hint = h; e.setText(v); e.setTextColor(Color.WHITE)
        e.setHintTextColor(0x88FFFFFF.toInt())
        e.inputType = if (num) InputType.TYPE_CLASS_NUMBER else (InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        return e
    }

    private fun showForm(o: JSONObject, isNew: Boolean) {
        closeForm()
        val isWeb = o.getString("t") == "web"
        val name = et("Nama", o.getString("n"), false)
        val url = et("https://...", o.getString("u"), false)
        val w = et("Lebar", o.getInt("w").toString(), true)
        val h = et("Tinggi", o.getInt("h").toString(), true)
        val seek = SeekBar(this); seek.max = 100; seek.progress = o.getInt("a")
        val ok = Button(this); ok.text = "OK"
        val cancel = Button(this); cancel.text = "Batal"
        val box = card()
        val title = tv("Widget settings"); title.textSize = 18f
        box.addView(title)
        box.addView(tv("Nama")); box.addView(name)
        if (isWeb) { box.addView(tv("Link URL")); box.addView(url) }
        val row = LinearLayout(this)
        row.addView(w, LinearLayout.LayoutParams(0, -2, 1f)); row.addView(h, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(tv("Lebar / Tinggi (px)")); box.addView(row)
        box.addView(tv("Transparansi (kanan = jelas)")); box.addView(seek)
        val btns = LinearLayout(this)
        btns.addView(cancel, LinearLayout.LayoutParams(0, -2, 1f)); btns.addView(ok, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(btns)

        cancel.setOnClickListener { closeForm() }
        ok.setOnClickListener {
            var u = url.text.toString().trim()
            if (isWeb) {
                if (u.isEmpty()) { Toast.makeText(this, "Isi link dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (!u.startsWith("http")) u = "https://$u"
                o.put("u", u)
            }
            o.put("n", name.text.toString())
            o.put("w", (w.text.toString().toIntOrNull() ?: 450).coerceAtLeast(50))
            o.put("h", (h.text.toString().toIntOrNull() ?: 338).coerceAtLeast(50))
            o.put("a", seek.progress.coerceAtLeast(10))
            if (isNew) items.add(o) else killView(o.getString("id"))
            addWidget(o); save(); closeForm()
        }

        val p = lp((resources.displayMetrics.widthPixels * 0.92f).toInt(), -2, true, true)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; p.y = 120
        wm.addView(box, p); form = box
    }

    override fun onDestroy() {
        views.keys.toList().forEach { killView(it) }
        bubble?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        closeForm()
        super.onDestroy()
    }
}
