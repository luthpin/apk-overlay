package com.example.overlaystudio

import android.app.*
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

class OverlayService : Service() {
    companion object { var onPicked: ((String) -> Unit)? = null }

    private lateinit var wm: WindowManager
    private val items = mutableListOf<JSONObject>()
    private val views = mutableMapOf<String, FrameLayout>()
    private val params = mutableMapOf<String, LP>()
    private val borders = mutableMapOf<String, GradientDrawable>()
    private var edit = false
    private var bubble: TextView? = null
    private var bubbleP: LP? = null
    private var bubbleLeft = true
    private var dock: View? = null
    private var sheet: View? = null
    private var target: View? = null
    private val d: Float get() = resources.displayMetrics.density
    private val sw: Int get() = resources.displayMetrics.widthPixels
    private val sh: Int get() = resources.displayMetrics.heightPixels
    private val land: Boolean get() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private val accent = Color.parseColor("#2563EB")
    private val gray = Color.parseColor("#374151")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "ov").setContentTitle("Overlay aktif").setSmallIcon(android.R.drawable.ic_menu_edit).build())
        val arr = JSONArray(getSharedPreferences("p", 0).getString("items", "[]"))
        for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
        items.forEach { addWidget(it) }
        makeBubble()
    }

    // ---------- helpers ----------
    private fun px(v: Int) = (v * d).toInt()
    private fun kx() = if (land) "x1" else "x0"
    private fun ky() = if (land) "y1" else "y0"
    private fun posX(o: JSONObject) = o.optInt(kx(), o.optInt("x", 0))
    private fun posY(o: JSONObject) = o.optInt(ky(), o.optInt("y", 0))
    private fun save() { getSharedPreferences("p", 0).edit().putString("items", JSONArray(items).toString()).apply() }

    private fun lp(w: Int, h: Int, touch: Boolean, focus: Boolean = false): LP {
        var f = LP.FLAG_LAYOUT_NO_LIMITS
        if (!touch) f = f or LP.FLAG_NOT_TOUCHABLE
        if (!focus) f = f or LP.FLAG_NOT_FOCUSABLE
        val p = LP(w, h, LP.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }
    private fun rr(c: Int, r: Float): GradientDrawable { val g = GradientDrawable(); g.setColor(c); g.cornerRadius = r; return g }
    private fun tv(s: String, sz: Float = 14f): TextView { val t = TextView(this); t.text = s; t.textSize = sz; t.setTextColor(Color.WHITE); return t }
    private fun circ(s: String, c: Int): TextView {
        val t = tv(s, 17f); t.gravity = Gravity.CENTER
        val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(c); t.background = g; return t
    }
    private fun card(): LinearLayout {
        val b = LinearLayout(this); b.orientation = LinearLayout.VERTICAL; b.setPadding(px(16), px(14), px(16), px(14))
        b.background = rr(Color.parseColor("#F2111318"), px(24).toFloat()); return b
    }
    private fun lay(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun header(title: String): LinearLayout {
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
        val b = circ("←", gray); b.setOnClickListener { back() }
        val x = circ("✕", gray); x.setOnClickListener { back() }
        val t = tv(title, 17f); t.gravity = Gravity.CENTER
        r.addView(b, lay(px(40), px(40))); r.addView(t, lay(0, -2, 1f)); r.addView(x, lay(px(40), px(40)))
        return r
    }

    private fun place(v: View, tall: Boolean) {
        closeSheet()
        val p = if (land) lp((sw * 0.32f).toInt(), if (tall) (sh * 0.92f).toInt() else -2, true, true).also { it.gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        else lp((sw * 0.94f).toInt(), if (tall) (sh * 0.55f).toInt() else -2, true, true).also { it.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; it.y = px(16) }
        wm.addView(v, p); sheet = v
    }
    private fun closeSheet() { sheet?.let { wm.removeView(it) }; sheet = null }
    private fun closeDock() { dock?.let { wm.removeView(it) }; dock = null }
    private fun back() { closeSheet(); items.forEach { hl(it.getString("id"), false) }; if (edit) showDock() }

    // ---------- bubble ----------
    private fun makeBubble() {
        val s = px(44)
        val b = circ("", accent); b.alpha = 0.2f
        val p = lp(s, s, true); p.x = -s / 2; p.y = px(150)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; b.alpha = 1f }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) { if (!moved) showTarget(); moved = true }
                    if (moved) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(b, p) }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) setEdit(!edit) else {
                        val cx = p.x + s / 2; val cy = p.y + s / 2
                        val tx = sw / 2; val ty = sh - px(40) - px(28)
                        if (abs(cx - tx) < px(70) && abs(cy - ty) < px(70)) stopSelf()
                        else { bubbleLeft = cx < sw / 2; p.x = if (bubbleLeft) -s / 2 else sw - s / 2; wm.updateViewLayout(b, p) }
                        hideTarget()
                    }
                    b.alpha = if (edit) 1f else 0.2f
                }
            }
            true
        }
        wm.addView(b, p); bubble = b; bubbleP = p
    }
    private fun showTarget() {
        val t = circ("✕", Color.parseColor("#DC2626"))
        val p = lp(px(56), px(56), false); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(40)
        wm.addView(t, p); target = t
    }
    private fun hideTarget() { target?.let { wm.removeView(it) }; target = null }
    private fun bringBubble() { bubble?.let { wm.removeView(it); wm.addView(it, bubbleP) } }

    // ---------- widgets ----------
    private fun hl(id: String, on: Boolean) { borders[id]?.setStroke(if (on) 7 else 3, if (on) accent else Color.WHITE) }

    private fun typeName(o: JSONObject) = when (o.getString("t")) { "web" -> "web source"; "txt" -> "teks"; else -> "media" }

    private fun addWidget(o: JSONObject) {
        val id = o.getString("id")
        val root = FrameLayout(this)
        val content: View
        when (o.getString("t")) {
            "web" -> {
                val w = WebView(this)
                w.setBackgroundColor(0)
                w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.webViewClient = WebViewClient(); w.loadUrl(o.getString("u")); content = w
            }
            "txt" -> {
                val t = TextView(this); t.text = o.getString("u"); t.setTextColor(Color.WHITE); t.gravity = Gravity.CENTER
                t.setShadowLayer(4f, 0f, 0f, Color.BLACK)
                t.setAutoSizeTextTypeUniformWithConfiguration(10, 200, 2, TypedValue.COMPLEX_UNIT_SP); content = t
            }
            else -> { val iv = ImageView(this); iv.setImageURI(Uri.parse(o.getString("u"))); content = iv }
        }
        content.alpha = o.getInt("a") / 100f
        content.visibility = if (o.optBoolean("v", true)) View.VISIBLE else View.INVISIBLE
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.rotation = o.optInt("r", 0).toFloat()

        val p = lp(o.getInt("w"), o.getInt("h"), edit)
        p.x = posX(o); p.y = posY(o)

        val ctl = FrameLayout(this)
        ctl.visibility = if (edit) View.VISIBLE else View.GONE
        val border = View(this)
        val g = GradientDrawable(); g.setColor(0x14FFFFFF); g.setStroke(3, Color.WHITE); border.background = g
        borders[id] = g
        ctl.addView(border)
        val shield = View(this); ctl.addView(shield)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        shield.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    var nx = ox + (e.rawX - sx).toInt(); var ny = oy + (e.rawY - sy).toInt()
                    if (abs(nx + p.width / 2 - sw / 2) < 15) nx = sw / 2 - p.width / 2
                    if (abs(ny + p.height / 2 - sh / 2) < 15) ny = sh / 2 - p.height / 2
                    p.x = nx; p.y = ny; wm.updateViewLayout(root, p)
                }
                MotionEvent.ACTION_UP -> { o.put(kx(), p.x).put(ky(), p.y); save() }
            }
            true
        }
        val sz = px(34)
        val gear = circ("⚙", gray); gear.setOnClickListener { showSettings(o, false) }
        val del = circ("✕", Color.parseColor("#DC2626")); del.setOnClickListener { confirmDelete(o) }
        ctl.addView(gear, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.START))
        ctl.addView(del, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END))
        val label = tv("", 13f); label.gravity = Gravity.CENTER; label.setBackgroundColor(0xAA000000.toInt()); label.visibility = View.GONE
        ctl.addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val hd = circ("⤡", accent)
        ctl.addView(hd, FrameLayout.LayoutParams(sz, sz, Gravity.BOTTOM or Gravity.END))
        var rw = 0; var rh = 0
        hd.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; rw = p.width; rh = p.height; hl(id, true); label.visibility = View.VISIBLE }
                MotionEvent.ACTION_MOVE -> {
                    p.width = (rw + (e.rawX - sx).toInt()).coerceAtLeast(60); p.height = (rh + (e.rawY - sy).toInt()).coerceAtLeast(60)
                    label.text = "W: ${p.width}  H: ${p.height}"; wm.updateViewLayout(root, p)
                }
                MotionEvent.ACTION_UP -> { o.put("w", p.width).put("h", p.height); save(); hl(id, false); label.visibility = View.GONE }
            }
            true
        }
        root.addView(ctl)
        wm.addView(root, p)
        views[id] = root; params[id] = p
        bringBubble()
    }

    private fun killView(id: String) {
        val v = views.remove(id) ?: return
        params.remove(id); borders.remove(id)
        wm.removeView(v)
        (v.getChildAt(0) as? WebView)?.destroy()
    }

    private fun setEdit(on: Boolean) {
        edit = on
        bubble?.alpha = if (on) 1f else 0.2f
        for ((id, v) in views) {
            val p = params[id]!!
            p.flags = if (on) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
            v.getChildAt(1).visibility = if (on) View.VISIBLE else View.GONE
            wm.updateViewLayout(v, p)
        }
        if (on) showDock() else { closeSheet(); closeDock() }
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        for (o in items) {
            val id = o.getString("id"); val p = params[id] ?: continue
            p.x = posX(o); p.y = posY(o); wm.updateViewLayout(views[id], p)
        }
        bubbleP?.let { it.x = if (bubbleLeft) -px(22) else sw - px(22); it.y = it.y.coerceIn(0, sh - px(44)); wm.updateViewLayout(bubble, it) }
        if (sheet != null) back() else if (dock != null) showDock()
    }

    // ---------- dock & sheets ----------
    private fun showDock() {
        closeDock()
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(px(8), px(8), px(8), px(8))
        r.background = rr(Color.parseColor("#EE111318"), px(40).toFloat())
        val add = tv("＋  Add Widget"); add.gravity = Gravity.CENTER; add.setPadding(px(18), px(10), px(18), px(10))
        add.background = rr(accent, px(30).toFloat()); add.setOnClickListener { showAdd() }
        val ly = circ("☰", gray); ly.setOnClickListener { showLayers() }
        val x = circ("✕", gray); x.setOnClickListener { stopSelf() }
        r.addView(add)
        r.addView(ly, lay(px(40), px(40)).also { it.leftMargin = px(8) })
        r.addView(x, lay(px(40), px(40)).also { it.leftMargin = px(8) })
        val p = lp(-2, -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(20)
        wm.addView(r, p); dock = r
    }

    private fun newItem(t: String, u: String): JSONObject {
        val w = when (t) { "web" -> 450; "txt" -> 400; else -> 400 }
        val h = when (t) { "web" -> 338; "txt" -> 120; else -> 300 }
        return JSONObject().put("id", System.currentTimeMillis().toString()).put("t", t)
            .put("n", typeName(JSONObject().put("t", t)).replaceFirstChar { it.uppercase() }).put("u", u)
            .put("w", w).put("h", h).put("a", 100).put("r", 0).put("v", true)
            .put("x0", (sw - w) / 2).put("y0", (sh - h) / 2).put("x1", (sw - w) / 2).put("y1", (sh - h) / 2)
    }

    private fun showAdd() {
        closeDock()
        val box = card(); box.addView(header("Add Widget"))
        val row = LinearLayout(this); row.gravity = Gravity.CENTER; row.setPadding(0, px(16), 0, px(8))
        fun opt(label: String, icon: String, act: () -> Unit) {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER; c.setPadding(px(14), 0, px(14), 0)
            c.addView(circ(icon, gray), lay(px(56), px(56))); c.addView(tv(label, 12f)); c.setOnClickListener { act() }
            row.addView(c)
        }
        opt("Media", "🖼") {
            onPicked = { u -> Handler(Looper.getMainLooper()).post { showSettings(newItem("pic", u), true) } }
            startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        opt("Web Source", "🌐") { showSettings(newItem("web", ""), true) }
        opt("Text", "T") { showSettings(newItem("txt", "Teks kamu"), true) }
        box.addView(row); place(box, false)
    }

    private fun showLayers() {
        closeDock()
        val box = card(); box.addView(header("Layers"))
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        fun build() {
            list.removeAllViews()
            if (items.isEmpty()) list.addView(tv("Belum ada widget"))
            for (o in items.reversed()) {
                val id = o.getString("id")
                val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, px(6), 0, px(6))
                val n = tv(o.getString("n") + "  · " + typeName(o)); n.setPadding(px(4), px(8), px(4), px(8))
                n.setOnClickListener { items.forEach { hl(it.getString("id"), false) }; hl(id, true) }
                val sw2 = Switch(this); sw2.isChecked = o.optBoolean("v", true)
                sw2.setOnCheckedChangeListener { _, c -> o.put("v", c); views[id]?.getChildAt(0)?.visibility = if (c) View.VISIBLE else View.INVISIBLE; save() }
                val up = circ("▲", gray); val dn = circ("▼", gray)
                up.setOnClickListener { val i = items.indexOf(o); if (i < items.size - 1) { items.removeAt(i); items.add(i + 1, o); restack(); save(); build() } }
                dn.setOnClickListener { val i = items.indexOf(o); if (i > 0) { items.removeAt(i); items.add(i - 1, o); restack(); save(); build() } }
                r.addView(n, lay(0, -2, 1f)); r.addView(sw2)
                r.addView(up, lay(px(34), px(34)).also { it.leftMargin = px(8) }); r.addView(dn, lay(px(34), px(34)).also { it.leftMargin = px(4) })
                list.addView(r)
            }
        }
        build()
        val sc = ScrollView(this); sc.addView(list); box.addView(sc); place(box, true)
    }

    private fun restack() {
        for (o in items) { val id = o.getString("id"); val v = views[id] ?: continue; wm.removeView(v); wm.addView(v, params[id]) }
        bringBubble()
    }

    private fun confirmDelete(o: JSONObject) {
        closeDock()
        val box = card()
        val extra = if (o.getString("t") == "web") " - " + o.getString("u").take(30) else ""
        val t = tv("Kamu ingin menghapus widget ${typeName(o)} - ${o.getString("n")}$extra ?", 15f); t.setPadding(0, 0, 0, px(12))
        val row = LinearLayout(this)
        val no = Button(this); no.text = "Batal"; no.setOnClickListener { back() }
        val yes = Button(this); yes.text = "Hapus"
        yes.setOnClickListener { val id = o.getString("id"); killView(id); items.remove(o); save(); back() }
        row.addView(no, lay(0, -2, 1f)); row.addView(yes, lay(0, -2, 1f))
        box.addView(t); box.addView(row); place(box, false)
    }

    private fun showSettings(o: JSONObject, isNew: Boolean) {
        closeDock()
        val t = o.getString("t")
        fun et(v: String, text: Boolean = false): EditText {
            val e = EditText(this); e.setText(v); e.setTextColor(Color.WHITE); e.setHintTextColor(0x88FFFFFF.toInt()); e.textSize = 14f
            e.inputType = if (text) InputType.TYPE_CLASS_TEXT else (InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED); return e
        }
        val name = et(o.getString("n"), true)
        val url = et(o.getString("u"), true); url.hint = "https://..."
        val fx = et(posX(o).toString()); val fy = et(posY(o).toString())
        val fw = et(o.getInt("w").toString()); val fh = et(o.getInt("h").toString())
        val fr = et(o.optInt("r", 0).toString())
        val seek = SeekBar(this); seek.max = 100; seek.progress = o.getInt("a")
        val form = LinearLayout(this); form.orientation = LinearLayout.VERTICAL
        fun pair(a: String, x: EditText, b: String, y: EditText?) {
            val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(tv(a, 12f), lay(px(24), -2)); r.addView(x, lay(0, -2, 1f))
            if (y != null) { r.addView(tv(b, 12f), lay(px(24), -2)); r.addView(y, lay(0, -2, 1f)) }
            form.addView(r)
        }
        form.addView(tv("Nama", 12f)); form.addView(name)
        if (t != "pic") { form.addView(tv(if (t == "web") "Link URL" else "Teks", 12f)); form.addView(url) }
        form.addView(tv("Position", 13f)); pair("X", fx, "Y", fy)
        form.addView(tv("Scale", 13f)); pair("W", fw, "H", fh)
        form.addView(tv("Rotate (°)", 13f)); form.addView(fr)
        form.addView(tv("Alignment", 13f))
        val icons = arrayOf("↖", "↑", "↗", "←", "●", "→", "↙", "↓", "↘")
        for (ay in 0..2) {
            val r = LinearLayout(this); r.gravity = Gravity.CENTER
            for (ax in 0..2) {
                val b = circ(icons[ay * 3 + ax], gray)
                b.setOnClickListener {
                    val w = fw.text.toString().toIntOrNull() ?: 100; val h = fh.text.toString().toIntOrNull() ?: 100
                    fx.setText(((sw - w) * ax / 2).toString()); fy.setText(((sh - h) * ay / 2).toString())
                }
                r.addView(b, lay(px(42), px(42)).also { it.setMargins(px(4), px(4), px(4), px(4)) })
            }
            form.addView(r)
        }
        form.addView(tv("Transparansi (kanan = jelas)", 12f)); form.addView(seek)
        val btns = LinearLayout(this)
        val cancel = Button(this); cancel.text = "Batal"; cancel.setOnClickListener { back() }
        val ok = Button(this); ok.text = "OK"
        ok.setOnClickListener {
            var u = url.text.toString().trim()
            if (t != "pic") {
                if (u.isEmpty()) { Toast.makeText(this, "Isi dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (t == "web" && !u.startsWith("http")) u = "https://$u"
                o.put("u", u)
            }
            o.put("n", name.text.toString())
            o.put(kx(), fx.text.toString().toIntOrNull() ?: 0).put(ky(), fy.text.toString().toIntOrNull() ?: 0)
            o.put("w", (fw.text.toString().toIntOrNull() ?: 400).coerceAtLeast(60)).put("h", (fh.text.toString().toIntOrNull() ?: 300).coerceAtLeast(60))
            o.put("r", fr.text.toString().toIntOrNull() ?: 0).put("a", seek.progress.coerceAtLeast(10))
            if (isNew) items.add(o) else killView(o.getString("id"))
            addWidget(o); save(); back()
        }
        btns.addView(cancel, lay(0, -2, 1f)); btns.addView(ok, lay(0, -2, 1f))
        val box = card(); box.addView(header("Widget Settings"))
        val sc = ScrollView(this); sc.addView(form); box.addView(sc, lay(-1, 0, 1f)); box.addView(btns)
        place(box, true)
    }

    override fun onDestroy() {
        views.keys.toList().forEach { killView(it) }
        bubble?.let { wm.removeView(it) }
        closeSheet(); closeDock(); hideTarget()
        super.onDestroy()
    }
}
