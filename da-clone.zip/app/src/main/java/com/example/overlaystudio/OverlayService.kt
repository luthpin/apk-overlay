package com.example.overlaystudio

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.*
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.view.animation.LinearInterpolator
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

class OverlayService : Service() {
    companion object { var onPicked: ((String) -> Unit)? = null }

    private lateinit var wm: WindowManager
    private val items = mutableListOf<JSONObject>()
    private val views = mutableMapOf<String, FrameLayout>()
    private val params = mutableMapOf<String, LP>()
    private val borders = mutableMapOf<String, GradientDrawable>()
    private var edit = false
    private var bubble: View? = null
    private var bubbleP: LP? = null
    private var bubbleLeft = true
    private var dock: View? = null
    private var sheet: View? = null
    private var target: View? = null
    private var gv: View? = null
    private var gh: View? = null
    private var arrow: View? = null
    private var peek = false
    private var galpha = 80
    private var dock2: View? = null
    private val anims = mutableMapOf<String, Animator>()
    private val h = Handler(Looper.getMainLooper())
    private val d: Float get() = resources.displayMetrics.density
    private fun dm(): DisplayMetrics { val m = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m); return m }
    private val sw: Int get() = dm().widthPixels
    private val sh: Int get() = dm().heightPixels
    private val land: Boolean get() = sw > sh
    private val accent = Color.parseColor("#2563EB")
    private val gray = Color.parseColor("#374151")
    private val ink = Color.parseColor("#111111")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "ov").setContentTitle("Overlay aktif").setSmallIcon(android.R.drawable.ic_menu_edit).build())
        galpha = getSharedPreferences("p", 0).getInt("galpha", 80)
        val arr = JSONArray(getSharedPreferences("p", 0).getString("items", "[]"))
        for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
        items.forEach { addWidget(it) }
        makeBubble()
    }

    // ---------- helpers ----------
    private fun px(v: Int) = (v * d).toInt()
    private fun kx() = if (land) "x1" else "x0"
    private fun ky() = if (land) "y1" else "y0"
    private fun posX(o: JSONObject) = o.optInt(kx(), (sw - o.getInt("w")) / 2)
    private fun posY(o: JSONObject) = o.optInt(ky(), (sh - o.getInt("h")) / 2)
    private fun save() { getSharedPreferences("p", 0).edit().putString("items", JSONArray(items).toString()).apply() }
    private fun lp(w: Int, hh: Int, touch: Boolean, focus: Boolean = false): LP {
        var f = LP.FLAG_LAYOUT_NO_LIMITS or LP.FLAG_HARDWARE_ACCELERATED
        if (!touch) f = f or LP.FLAG_NOT_TOUCHABLE
        if (!focus) f = f or LP.FLAG_NOT_FOCUSABLE
        val p = LP(w, hh, LP.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }
    private fun rr(c: Int, r: Float): GradientDrawable { val g = GradientDrawable(); g.setColor(c); g.cornerRadius = r; return g }
    private fun tv(s: String, sz: Float = 14f, c: Int = Color.WHITE): TextView { val t = TextView(this); t.text = s; t.textSize = sz; t.setTextColor(c); return t }
    private fun cb(n: String, bg: Int, fg: Int = Color.WHITE, pad: Int = 9): ImageView {
        val v = ImageView(this); v.setImageResource(resources.getIdentifier("ic_$n", "drawable", packageName)); v.setColorFilter(fg)
        v.setPadding(px(pad), px(pad), px(pad), px(pad))
        val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(bg); v.background = g; return v
    }
    private fun card(): LinearLayout {
        val b = LinearLayout(this); b.orientation = LinearLayout.VERTICAL; b.setPadding(px(16), px(14), px(16), px(14))
        b.background = rr(Color.parseColor("#F2111318"), px(24).toFloat()); return b
    }
    private fun lay(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)
    private fun typeName(o: JSONObject) = when (o.getString("t")) { "web" -> "web source"; "txt" -> "teks"; else -> "media" }
    private fun hl(id: String, on: Boolean) { borders[id]?.setStroke(if (on) 7 else 3, if (on) accent else Color.WHITE) }

    private fun header(title: String): LinearLayout {
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
        val b = cb("back", gray); b.setOnClickListener { back() }
        val x = cb("close", gray); x.setOnClickListener { back() }
        val t = tv(title, 17f); t.gravity = Gravity.CENTER; t.setPadding(px(20), 0, px(20), 0)
        r.addView(b, lay(px(38), px(38))); r.addView(t, lay(0, -2, 1f)); r.addView(x, lay(px(38), px(38)))
        return r
    }
    private fun place(v: View, tall: Boolean, wide: Boolean) {
        closeSheet()
        val p = if (land) lp(if (wide) (sw * 0.32f).toInt() else -2, if (tall) (sh * 0.92f).toInt() else -2, true, true).also { it.gravity = Gravity.END or Gravity.CENTER_VERTICAL; it.x = px(8) }
        else lp(if (wide) (sw * 0.94f).toInt() else -2, if (tall) (sh * 0.55f).toInt() else -2, true, true).also { it.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; it.y = px(16) }
        wm.addView(v, p); sheet = v
        v.scaleX = 0.9f; v.scaleY = 0.9f; v.alpha = 0f; v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
    }
    private fun closeSheet() { sheet?.let { wm.removeView(it) }; sheet = null }
    private fun closeDock() { dock?.let { wm.removeView(it) }; dock = null; dock2?.let { wm.removeView(it) }; dock2 = null }
    private fun back() { save(); closeSheet(); items.forEach { hl(it.getString("id"), false) }; if (edit) showDock() }

    private fun guides(v: Boolean, hz: Boolean) {
        if (v && gv == null) { val x = View(this); x.setBackgroundColor(accent); val p = lp(px(2), sh, false); p.x = sw / 2 - px(1); wm.addView(x, p); gv = x }
        if (!v && gv != null) { wm.removeView(gv); gv = null }
        if (hz && gh == null) { val x = View(this); x.setBackgroundColor(accent); val p = lp(sw, px(2), false); p.y = sh / 2 - px(1); wm.addView(x, p); gh = x }
        if (!hz && gh != null) { wm.removeView(gh); gh = null }
    }

    // ---------- bubble ----------
    private fun thin(on: Boolean) {
        val b = bubble ?: return; val p = bubbleP ?: return
        if (on) { p.width = px(16); p.height = px(60); b.background = rr(accent, px(8).toFloat()) }
        else { p.width = px(44); p.height = px(44); val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(accent); b.background = g }
        wm.updateViewLayout(b, p)
    }
    private fun snapBubble() {
        val p = bubbleP ?: return
        p.y = p.y.coerceIn(px(40), sh - px(130)); p.x = if (bubbleLeft) px(2) else sw - px(18)
        thin(true)
    }
    private fun makeBubble() {
        val b = View(this)
        val p = lp(px(16), px(60), true); p.y = px(150); p.x = px(2)
        bubble = b; bubbleP = p; b.alpha = 0.35f; b.background = rr(accent, px(8).toFloat())
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var circle = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; circle = false; b.alpha = 1f }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        p.x = ox + dx; p.y = oy + dy
                        val far = minOf(p.x + p.width / 2, sw - p.x - p.width / 2) > px(70)
                        if (far && !circle) { circle = true; thin(false); showTarget() }
                        else if (!far && circle) { circle = false; hideTarget(); thin(true) }
                        wm.updateViewLayout(b, p)
                        target?.let { val n = nearTarget(e.rawX, e.rawY); it.scaleX = if (n) 1.3f else 1f; it.scaleY = it.scaleX }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) { if (edit) setEdit(false) else setPeek(!peek) }
                    else {
                        val cx = p.x + p.width / 2; val cy = p.y + p.height / 2
                        if (nearTarget(e.rawX, e.rawY)) stopSelf()
                        else { bubbleLeft = cx < sw / 2; hideTarget(); snapBubble() }
                    }
                    b.alpha = if (edit || peek) 1f else 0.35f
                }
            }
            true
        }
        wm.addView(b, p)
    }
    private fun showTarget() {
        val t = cb("close", Color.parseColor("#DC2626"), Color.WHITE, 14)
        val p = lp(px(56), px(56), false); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(95)
        wm.addView(t, p); target = t
    }
    private fun nearTarget(x: Float, y: Float): Boolean {
        val t = target ?: return false; val loc = IntArray(2); t.getLocationOnScreen(loc)
        return abs(x - (loc[0] + t.width / 2f)) < px(80) && abs(y - (loc[1] + t.height / 2f)) < px(80)
    }
    private fun hideTarget() { target?.let { wm.removeView(it) }; target = null }
    private fun bringBubble() { bubble?.let { wm.removeView(it); wm.addView(it, bubbleP) } }
    private fun showArrow() {
        hideArrow()
        val a = FrameLayout(this); a.background = rr(ink, px(12).toFloat()); a.alpha = 0.3f
        val i = ImageView(this); i.setImageResource(resources.getIdentifier("ic_up", "drawable", packageName)); i.setColorFilter(Color.WHITE)
        i.setPadding(px(8), px(8), px(8), px(8)); a.addView(i)
        a.setOnClickListener { setPeek(false); setEdit(true) }
        val p = lp(px(44), px(44), true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(28)
        wm.addView(a, p); arrow = a
    }
    private fun hideArrow() { arrow?.let { wm.removeView(it) }; arrow = null }
    private fun setPeek(on: Boolean) {
        peek = on; bubble?.alpha = if (on || edit) 1f else 0.35f
        ctlMode(0)
        setAlphaAll(if (on) 1f else galpha / 100f)
        if (on) showArrow() else hideArrow()
    }

    // ---------- widgets ----------
    private fun loadBmp(u: Uri): Bitmap {
        val o1 = BitmapFactory.Options(); o1.inJustDecodeBounds = true
        contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o1) }
        var ss = 1; while (o1.outWidth / ss > 1200 || o1.outHeight / ss > 1200) ss *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
        return contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o2)!! }
    }
    private fun shadowed(b: Bitmap, r: Int): Bitmap {
        val rad = r * 2f; val pad = (rad * 2).toInt() + 2
        val out = Bitmap.createBitmap(b.width + pad * 2, b.height + pad * 2, Bitmap.Config.ARGB_8888); val c = Canvas(out)
        val pt = Paint(); pt.maskFilter = BlurMaskFilter(rad, BlurMaskFilter.Blur.NORMAL)
        val off = IntArray(2); val a = b.extractAlpha(pt, off)
        val bp = Paint(); bp.color = Color.BLACK
        c.drawBitmap(a, (pad + off[0]).toFloat(), (pad + off[1]).toFloat(), bp)
        c.drawBitmap(b, pad.toFloat(), pad.toFloat(), null)
        return out
    }
    private fun boxOf(id: String) = views[id]?.getChildAt(0) as? FrameLayout
    private fun contentOf(id: String) = boxOf(id)?.getChildAt(0)
    private fun ctlOf(id: String) = boxOf(id)?.getChildAt(1) as? FrameLayout
    private fun ctlMode(m: Int) {
        for (id in views.keys) {
            val c = ctlOf(id) ?: continue
            c.visibility = if (m == 0) View.GONE else View.VISIBLE
            for (i in intArrayOf(1, 3, 4)) c.getChildAt(i).visibility = if (m == 2) View.VISIBLE else View.GONE
        }
    }
    private fun relayout(o: JSONObject) {
        val id = o.getString("id"); val p = params[id] ?: return; val v = views[id] ?: return
        val w = o.getInt("w"); val hh = o.getInt("h")
        val th = Math.toRadians(o.optInt("r", 0).toDouble()); val c = abs(Math.cos(th)); val sn = abs(Math.sin(th))
        val bw = (w * c + hh * sn).toInt(); val bh = (w * sn + hh * c).toInt()
        p.width = bw; p.height = bh; p.x = posX(o) - (bw - w) / 2; p.y = posY(o) - (bh - hh) / 2
        val box = v.getChildAt(0) as FrameLayout
        val l = box.layoutParams as FrameLayout.LayoutParams; l.width = w; l.height = hh; l.gravity = Gravity.CENTER
        box.layoutParams = l; box.rotation = o.optInt("r", 0).toFloat()
        wm.updateViewLayout(v, p)
    }

    private fun addWidget(o: JSONObject) {
        val id = o.getString("id")
        val root = FrameLayout(this); val box = FrameLayout(this)
        box.setBackgroundColor(Color.argb(o.optInt("bg", 0) * 255 / 100, 0, 0, 0))
        val content: View
        var clp = FrameLayout.LayoutParams(-1, -1)
        when (o.getString("t")) {
            "web" -> {
                val w = WebView(this); w.setBackgroundColor(0); w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.mediaPlaybackRequiresUserGesture = false
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView?, u: String?) {
                        val sd = o.optInt("sh", 0)
                        if (sd > 0) v?.evaluateJavascript("document.documentElement.style.filter='drop-shadow(0 0 ${sd}px black)'", null)
                    }
                }
                w.loadUrl(o.getString("u")); content = w
            }
            "txt" -> {
                val t = TextView(this); t.text = o.getString("u"); t.setTextColor(o.optInt("c", Color.WHITE))
                val sd = o.optInt("sh", 4); if (sd > 0) t.setShadowLayer(sd.toFloat(), 0f, 0f, Color.BLACK)
                t.typeface = Typeface.create(o.optString("f", "sans-serif"), (if (o.optBoolean("b", false)) 1 else 0) or (if (o.optBoolean("i", false)) 2 else 0))
                val st = o.optString("s", "none")
                if (st == "run") {
                    t.setSingleLine(); t.setTextSize(TypedValue.COMPLEX_UNIT_PX, o.getInt("h") * 0.5f); t.gravity = Gravity.CENTER_VERTICAL
                    clp = FrameLayout.LayoutParams(-2, -1)
                    t.post {
                        val bw = o.getInt("w").toFloat(); val tw = t.width.toFloat()
                        val a = ValueAnimator.ofFloat(bw, -tw); a.duration = ((bw + tw) / d * 14).toLong().coerceAtLeast(2000)
                        a.interpolator = LinearInterpolator(); a.repeatCount = ValueAnimator.INFINITE
                        a.addUpdateListener { t.translationX = it.animatedValue as Float }; a.start(); anims[id] = a
                    }
                } else {
                    t.gravity = Gravity.CENTER; t.setAutoSizeTextTypeUniformWithConfiguration(10, 200, 2, TypedValue.COMPLEX_UNIT_SP)
                    if (st == "blink") { val a = ObjectAnimator.ofFloat(t, "alpha", 1f, 0.15f); a.duration = 600; a.repeatCount = ValueAnimator.INFINITE; a.repeatMode = ValueAnimator.REVERSE; a.start(); anims[id] = a }
                    if (st == "pulse") {
                        val a = ObjectAnimator.ofPropertyValuesHolder(t, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.15f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.15f))
                        a.duration = 700; a.repeatCount = ValueAnimator.INFINITE; a.repeatMode = ValueAnimator.REVERSE; a.start(); anims[id] = a
                    }
                }
                content = t
            }
            else -> {
                val iv = ImageView(this); val uri = Uri.parse(o.getString("u")); var ok = false
                if (o.optInt("sh", 0) > 0) { try { iv.setImageBitmap(shadowed(loadBmp(uri), o.getInt("sh"))); ok = true } catch (e: Exception) {} }
                if (!ok) iv.setImageURI(uri)
                content = iv
            }
        }
        if (o.getString("t") != "txt" || o.optString("s", "none") == "none") content.alpha = o.getInt("a") / 100f
        content.visibility = if (o.optBoolean("v", true)) View.VISIBLE else View.INVISIBLE
        box.addView(content, clp)

        val ctl = FrameLayout(this); ctl.visibility = if (edit) View.VISIBLE else View.GONE
        val border = View(this)
        val g = GradientDrawable(); g.setColor(0x14FFFFFF); g.setStroke(3, Color.WHITE); border.background = g
        borders[id] = g; ctl.addView(border)
        val shield = View(this); ctl.addView(shield)
        val label = tv("", 13f); label.setBackgroundColor(0xAA000000.toInt()); label.visibility = View.GONE
        ctl.addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val sz = px(34)
        val gear = cb("gear", gray); gear.setOnClickListener { showSettings(o, false) }
        val del = cb("close", Color.parseColor("#DC2626")); del.setOnClickListener { confirmDelete(o) }
        ctl.addView(gear, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.START))
        ctl.addView(del, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END))
        box.addView(ctl)
        root.addView(box, FrameLayout.LayoutParams(o.getInt("w"), o.getInt("h"), Gravity.CENTER))
        val p = lp(10, 10, edit); p.alpha = if (edit || peek) 1f else galpha / 100f
        wm.addView(root, p); views[id] = root; params[id] = p; relayout(o); bringBubble()

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var rs = false; var mv = false
        val rrun = Runnable { rs = true; hl(id, true); label.visibility = View.VISIBLE; Toast.makeText(this, "Resize widget", Toast.LENGTH_SHORT).show() }
        shield.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; rs = false; mv = false
                    val m = px(30)
                    if (e.x < m || e.y < m || e.x > o.getInt("w") - m || e.y > o.getInt("h") - m) h.postDelayed(rrun, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 12 || abs(e.rawY - sy) > 12) { mv = true; if (!rs) h.removeCallbacks(rrun) }
                    if (rs) {
                        o.put("w", (e.rawX - posX(o)).toInt().coerceAtLeast(60)); o.put("h", (e.rawY - posY(o)).toInt().coerceAtLeast(60))
                        label.text = "W: ${o.getInt("w")}  H: ${o.getInt("h")}"; relayout(o)
                    } else if (mv) {
                        var nx = ox + (e.rawX - sx).toInt(); var ny = oy + (e.rawY - sy).toInt()
                        val s1 = abs(nx + p.width / 2 - sw / 2) < 15; val s2 = abs(ny + p.height / 2 - sh / 2) < 15
                        if (s1) nx = sw / 2 - p.width / 2
                        if (s2) ny = sh / 2 - p.height / 2
                        guides(s1, s2); p.x = nx; p.y = ny; wm.updateViewLayout(root, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(rrun); guides(false, false)
                    if (rs) { hl(id, false); label.visibility = View.GONE }
                    else if (mv) o.put(kx(), p.x + (p.width - o.getInt("w")) / 2).put(ky(), p.y + (p.height - o.getInt("h")) / 2)
                    save()
                }
            }
            true
        }
    }
    private fun killView(id: String) {
        val v = views.remove(id) ?: return
        params.remove(id); borders.remove(id); anims.remove(id)?.cancel(); wm.removeView(v)
        ((v.getChildAt(0) as FrameLayout).getChildAt(0) as? WebView)?.destroy()
    }
    private fun setEdit(on: Boolean) {
        edit = on; if (on) { peek = false; hideArrow() }
        bubble?.alpha = if (on) 1f else 0.35f
        ctlMode(if (on) 2 else 0)
        for ((id, v) in views) {
            val p = params[id]!!
            p.flags = if (on) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
            p.alpha = if (on) 1f else galpha / 100f
            wm.updateViewLayout(v, p)
        }
        if (on) showDock() else { closeSheet(); closeDock() }
    }
    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        h.postDelayed({
            for (o in items) relayout(o)
            snapBubble()
            if (peek) showArrow()
            if (sheet != null) back() else if (dock != null) showDock()
        }, 200)
    }
    private fun confirmClose() {
        closeDock()
        val box = card()
        val t = tv("Kamu yakin ingin menutup overlay app?", 15f); t.setPadding(0, 0, 0, px(12))
        val row = LinearLayout(this)
        val no = Button(this); no.text = "Batal"; no.setOnClickListener { back() }
        val yes = Button(this); yes.text = "Tutup"; yes.setOnClickListener { stopSelf() }
        row.addView(no, lay(0, -2, 1f)); row.addView(yes, lay(0, -2, 1f))
        box.addView(t); box.addView(row); place(box, false, false)
    }

    // ---------- dock & sheets ----------
    private fun showDock() {
        closeDock()
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(px(6), px(6), px(6), px(6))
        r.background = rr(Color.WHITE, px(40).toFloat())
        val add = LinearLayout(this); add.gravity = Gravity.CENTER_VERTICAL; add.setPadding(px(14), px(9), px(18), px(9))
        add.background = rr(ink, px(30).toFloat()); add.setOnClickListener { showAdd() }
        add.addView(cb("plus", ink, Color.WHITE, 2), lay(px(22), px(22))); val t = tv("Add Widget", 14f); t.setPadding(px(8), 0, 0, 0); add.addView(t)
        val ly = cb("layers", Color.parseColor("#E5E7EB"), ink, 10); ly.setOnClickListener { showLayers() }
        val x = cb("close", Color.parseColor("#E5E7EB"), ink, 10); x.setOnClickListener { confirmClose() }
        r.addView(add); r.addView(ly, lay(px(40), px(40)).also { it.leftMargin = px(6) }); r.addView(x, lay(px(40), px(40)).also { it.leftMargin = px(6) })
        val p = lp(-2, -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(20)
        wm.addView(r, p); dock = r
        r.translationY = px(70).toFloat(); r.alpha = 0f; r.animate().translationY(0f).alpha(1f).setDuration(220).start()
        showDockSlider()
    }
    private fun setAlphaAll(a: Float) { for ((id, v) in views) { params[id]?.let { it.alpha = a; wm.updateViewLayout(v, it) } } }
    private fun showDockSlider() {
        val box = card(); box.setPadding(px(14), px(8), px(14), px(8))
        val t = tv("Transparansi keseluruhan: $galpha%", 12f)
        val sk = SeekBar(this); sk.max = 80; sk.progress = galpha - 20
        sk.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { t.text = "Transparansi keseluruhan: ${p + 20}%"; setAlphaAll((p + 20) / 100f) } }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { galpha = sk.progress + 20; getSharedPreferences("p", 0).edit().putInt("galpha", galpha).apply(); setAlphaAll(1f) }
        })
        box.addView(t); box.addView(sk)
        val p = lp(px(280), -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(84)
        wm.addView(box, p); dock2 = box
    }
    private fun newItem(t: String, u: String): JSONObject {
        val w = if (t == "web") 450 else 400; val hh = when (t) { "web" -> 338; "txt" -> 120; else -> 300 }
        val a = minOf(sw, sh); val b = maxOf(sw, sh)
        return JSONObject().put("id", System.currentTimeMillis().toString()).put("t", t)
            .put("n", typeName(JSONObject().put("t", t)).replaceFirstChar { it.uppercase() }).put("u", u)
            .put("w", w).put("h", hh).put("a", 100).put("r", 0).put("v", true)
            .put("x0", (a - w) / 2).put("y0", (b - hh) / 2).put("x1", (b - w) / 2).put("y1", (a - hh) / 2)
    }
    private fun showAdd() {
        closeDock()
        val box = card(); box.addView(header("Add Widget"))
        val row = LinearLayout(this); row.gravity = Gravity.CENTER; row.setPadding(0, px(16), 0, px(4))
        fun opt(label: String, icon: String, act: () -> Unit) {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER; c.setPadding(px(12), 0, px(12), 0)
            c.addView(cb(icon, gray, Color.WHITE, 16), lay(px(58), px(58))); val t = tv(label, 12f); t.gravity = Gravity.CENTER; t.setPadding(0, px(6), 0, 0); c.addView(t)
            c.setOnClickListener { act() }; row.addView(c)
        }
        opt("Media", "image") {
            onPicked = { u -> h.post { showSettings(newItem("pic", u), true) } }
            startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        opt("Web Source", "globe") { showSettings(newItem("web", ""), true) }
        opt("Text", "text") { showSettings(newItem("txt", "Teks kamu"), true) }
        box.addView(row); place(box, false, false)
    }
    private fun restack() { for (o in items) { val id = o.getString("id"); val v = views[id] ?: continue; wm.removeView(v); wm.addView(v, params[id]) }; bringBubble() }

    private fun showLayers() {
        closeDock()
        val box = card(); box.addView(header("Layers"))
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        fun build() {
            list.removeAllViews()
            if (items.isEmpty()) list.addView(tv("Belum ada widget"))
            for (o in items.reversed()) {
                val id = o.getString("id")
                val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, px(5), 0, px(5)); r.tag = o
                val n = tv(o.getString("n") + "  · " + typeName(o)); n.setPadding(px(4), px(8), px(4), px(8))
                n.setOnClickListener { items.forEach { hl(it.getString("id"), false) }; hl(id, true) }
                val s = Switch(this); s.isChecked = o.optBoolean("v", true)
                s.setOnCheckedChangeListener { _, c -> o.put("v", c); contentOf(id)?.visibility = if (c) View.VISIBLE else View.INVISIBLE; save() }
                val gr = cb("gear", gray); gr.setOnClickListener { showSettings(o, false) }
                val grip = cb("grip", gray); var sy = 0f
                grip.setOnTouchListener { v, e ->
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sy = e.rawY; v.parent.requestDisallowInterceptTouchEvent(true) }
                        MotionEvent.ACTION_MOVE -> r.translationY = e.rawY - sy
                        MotionEvent.ACTION_UP -> {
                            val i = list.indexOfChild(r); val ni = (i + Math.round((e.rawY - sy) / r.height)).coerceIn(0, list.childCount - 1)
                            val order = (0 until list.childCount).map { list.getChildAt(it).tag as JSONObject }.toMutableList()
                            order.removeAt(i); order.add(ni, o)
                            items.clear(); items.addAll(order.reversed()); restack(); save(); build()
                        }
                    }
                    true
                }
                r.addView(n, lay(0, -2, 1f)); r.addView(s); r.addView(gr, lay(px(34), px(34)).also { it.leftMargin = px(8) }); r.addView(grip, lay(px(34), px(34)).also { it.leftMargin = px(6) })
                list.addView(r)
            }
        }
        build()
        val sc = ScrollView(this); sc.addView(list); box.addView(sc); place(box, false, true)
    }
    private fun confirmDelete(o: JSONObject) {
        closeDock()
        val box = card()
        val extra = if (o.getString("t") == "web") " - " + o.getString("u").take(30) else ""
        val t = tv("Kamu ingin menghapus widget ${typeName(o)} - ${o.getString("n")}$extra ?", 15f); t.maxWidth = px(300); t.setPadding(0, 0, 0, px(12))
        val row = LinearLayout(this)
        val no = Button(this); no.text = "Batal"; no.setOnClickListener { back() }
        val yes = Button(this); yes.text = "Hapus"; yes.setOnClickListener { killView(o.getString("id")); items.remove(o); save(); back() }
        row.addView(no, lay(0, -2, 1f)); row.addView(yes, lay(0, -2, 1f))
        box.addView(t); box.addView(row); place(box, false, false)
    }

    private fun showSettings(o: JSONObject, isNew: Boolean) {
        closeDock()
        val id = o.getString("id"); val t = o.getString("t")
        val snap = JSONObject(o.toString())
        if (isNew) { items.add(o); addWidget(o) }
        var liveCb: () -> Unit = {}
        fun rebuild() { killView(id); addWidget(o); restack() }
        fun et(v: String, text: Boolean = false): EditText {
            val e = EditText(this); e.setText(v); e.setTextColor(Color.WHITE); e.setHintTextColor(0x88FFFFFF.toInt()); e.textSize = 14f
            e.inputType = if (text) InputType.TYPE_CLASS_TEXT else (InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED); return e
        }
        val form = LinearLayout(this); form.orientation = LinearLayout.VERTICAL
        fun sl(label: String, mn: Int, mx: Int, v: Int): EditText {
            val e = et(v.toString()); val s = SeekBar(this); s.max = mx - mn; s.progress = (v - mn).coerceIn(0, mx - mn)
            var lock = false
            s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { lock = true; e.setText((p + mn).toString()); lock = false; liveCb() } }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(x: Editable?) { if (!lock) { e.text.toString().toIntOrNull()?.let { s.progress = (it - mn).coerceIn(0, mx - mn) }; liveCb() } }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
            })
            val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(tv(label, 13f), lay(px(70), -2)); r.addView(s, lay(0, -2, 1f)); r.addView(e, lay(px(70), -2))
            form.addView(r); return e
        }
        val name = et(o.getString("n"), true); val url = et(o.getString("u"), true); url.hint = "https://..."
        form.addView(tv("Nama", 12f)); form.addView(name)
        if (t != "pic") { form.addView(tv(if (t == "web") "Link URL" else "Teks", 12f)); form.addView(url) }
        if (t == "txt") {
            form.addView(tv("Warna", 14f))
            val cr = LinearLayout(this); cr.setPadding(0, px(4), 0, px(4))
            for (c in intArrayOf(Color.WHITE, Color.parseColor("#FACC15"), Color.parseColor("#EF4444"), Color.parseColor("#22C55E"), Color.parseColor("#22D3EE"), Color.parseColor("#3B82F6"), Color.parseColor("#EC4899"), Color.BLACK)) {
                val dot = View(this); val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(c); g.setStroke(2, Color.GRAY); dot.background = g
                dot.setOnClickListener { o.put("c", c); rebuild() }
                cr.addView(dot, lay(px(30), px(30)).also { it.rightMargin = px(8) })
            }
            form.addView(cr)
            form.addView(tv("Efek", 14f))
            val sr = LinearLayout(this)
            for ((lb, key) in listOf("Tetap" to "none", "Jalan" to "run", "Kedip" to "blink", "Denyut" to "pulse")) {
                val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
                chip.setOnClickListener { o.put("s", key); rebuild() }
                sr.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
            }
            form.addView(sr)
            form.addView(tv("Font", 14f))
            val hs = HorizontalScrollView(this); val fr2 = LinearLayout(this); hs.addView(fr2)
            for ((lb, fam) in listOf("Sans" to "sans-serif", "Serif" to "serif", "Mono" to "monospace", "Tulis" to "cursive", "Lucu" to "casual", "Ramping" to "sans-serif-condensed", "Tebal" to "sans-serif-black")) {
                val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
                chip.setOnClickListener { o.put("f", fam); rebuild() }
                fr2.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
            }
            form.addView(hs)
            val bi = LinearLayout(this); bi.setPadding(0, px(6), 0, 0)
            for ((lb, key) in listOf("B  Bold" to "b", "I  Italic" to "i")) {
                val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
                chip.setOnClickListener { o.put(key, !o.optBoolean(key, false)); rebuild() }
                bi.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
            }
            form.addView(bi)
        }
        val big = maxOf(sw, sh)
        form.addView(tv("Position", 14f))
        val fx = sl("X", -sw, big, posX(o)); val fy = sl("Y", -sh, big, posY(o))
        form.addView(tv("Scale", 14f))
        val fw = sl("W", 60, big, o.getInt("w")); val fh = sl("H", 60, big, o.getInt("h"))
        form.addView(tv("Rotate", 14f))
        val fr = sl("°", -180, 180, o.optInt("r", 0))
        form.addView(tv("Alignment", 14f))
        val icons = arrayOf("↖", "↑", "↗", "←", "●", "→", "↙", "↓", "↘")
        for (ay in 0..2) {
            val r = LinearLayout(this); r.gravity = Gravity.CENTER
            for (ax in 0..2) {
                val b = tv(icons[ay * 3 + ax], 16f); b.gravity = Gravity.CENTER; b.background = rr(gray, px(12).toFloat())
                b.setOnClickListener {
                    val w = fw.text.toString().toIntOrNull() ?: 100; val hh = fh.text.toString().toIntOrNull() ?: 100
                    fx.setText(((sw - w) * ax / 2).toString()); fy.setText(((sh - hh) * ay / 2).toString())
                }
                r.addView(b, lay(px(44), px(40)).also { it.setMargins(px(4), px(3), px(4), px(3)) })
            }
            form.addView(r)
        }
        form.addView(tv("Transparansi (kanan = jelas)", 12f))
        val seek = SeekBar(this); seek.max = 100; seek.progress = o.getInt("a"); form.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { o.put("a", p.coerceAtLeast(10)); contentOf(id)?.alpha = p.coerceAtLeast(10) / 100f }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        form.addView(tv("Bayangan mengikuti bentuk (0 = mati)", 12f))
        val shS = SeekBar(this); shS.max = 20; shS.progress = o.optInt("sh", if (t == "txt") 4 else 0); form.addView(shS)
        shS.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { o.put("sh", shS.progress); rebuild() }
        })
        form.addView(tv("Latar gelap (0 = bening total)", 12f))
        val bgS = SeekBar(this); bgS.max = 80; bgS.progress = o.optInt("bg", 0); form.addView(bgS)
        bgS.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { o.put("bg", p); boxOf(id)?.setBackgroundColor(Color.argb(p * 255 / 100, 0, 0, 0)) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        liveCb = {
            o.put(kx(), fx.text.toString().toIntOrNull() ?: posX(o)).put(ky(), fy.text.toString().toIntOrNull() ?: posY(o))
            o.put("w", (fw.text.toString().toIntOrNull() ?: 60).coerceAtLeast(60)).put("h", (fh.text.toString().toIntOrNull() ?: 60).coerceAtLeast(60))
            o.put("r", fr.text.toString().toIntOrNull() ?: 0); relayout(o)
        }
        val btns = LinearLayout(this)
        val cancel = Button(this); cancel.text = "Batal"
        cancel.setOnClickListener {
            if (isNew) { killView(id); items.remove(o) } else { for (k in snap.keys()) o.put(k, snap.get(k)); rebuild() }
            back()
        }
        val ok = Button(this); ok.text = "OK"
        ok.setOnClickListener {
            var u = url.text.toString().trim()
            if (t != "pic") {
                if (u.isEmpty()) { Toast.makeText(this, "Isi dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (t == "web" && !u.startsWith("http")) u = "https://$u"
                o.put("u", u)
            }
            o.put("n", name.text.toString()); liveCb(); rebuild(); back()
        }
        btns.addView(cancel, lay(0, -2, 1f)); btns.addView(ok, lay(0, -2, 1f))
        val box = card(); box.addView(header("Widget Settings"))
        val sc = ScrollView(this); sc.addView(form); box.addView(sc, lay(-1, 0, 1f)); box.addView(btns)
        place(box, true, true)
    }

    override fun onDestroy() {
        views.keys.toList().forEach { killView(it) }
        bubble?.let { wm.removeView(it) }
        closeSheet(); closeDock(); hideTarget(); hideArrow(); guides(false, false)
        super.onDestroy()
    }
}
