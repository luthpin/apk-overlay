package com.example.overlaystudio

import android.app.*
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

class OverlayService : Service() {
    companion object { var onPicked: ((String) -> Unit)? = null }

    private lateinit var wm: WindowManager
    private val items = mutableListOf<JSONObject>()
    private val views = mutableMapOf<String, FrameLayout>()
    private val params = mutableMapOf<String, LP>()
    private val borders = mutableMapOf<String, GradientDrawable>()
    private var edit = false
    private var bubble: View? = null
    private var bubbleP: LP? = null
    private var bubbleLeft = true
    private var dock: View? = null
    private var sheet: View? = null
    private var target: View? = null
    private var gv: View? = null
    private var gh: View? = null
    private val h = Handler(Looper.getMainLooper())
    private val d: Float get() = resources.displayMetrics.density
    private fun dm(): DisplayMetrics { val m = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m); return m }
    private val sw: Int get() = dm().widthPixels
    private val sh: Int get() = dm().heightPixels
    private val land: Boolean get() = sw > sh
    private val accent = Color.parseColor("#2563EB")
    private val gray = Color.parseColor("#374151")
    private val ink = Color.parseColor("#111111")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, Notification.Builder(this, "ov").setContentTitle("Overlay aktif").setSmallIcon(android.R.drawable.ic_menu_edit).build())
        val arr = JSONArray(getSharedPreferences("p", 0).getString("items", "[]"))
        for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
        items.forEach { addWidget(it) }
        makeBubble()
    }

    // ---------- helpers ----------
    private fun px(v: Int) = (v * d).toInt()
    private fun kx() = if (land) "x1" else "x0"
    private fun ky() = if (land) "y1" else "y0"
    private fun posX(o: JSONObject) = o.optInt(kx(), (sw - o.getInt("w")) / 2)
    private fun posY(o: JSONObject) = o.optInt(ky(), (sh - o.getInt("h")) / 2)
    private fun save() { getSharedPreferences("p", 0).edit().putString("items", JSONArray(items).toString()).apply() }
    private fun lp(w: Int, hh: Int, touch: Boolean, focus: Boolean = false): LP {
        var f = LP.FLAG_LAYOUT_NO_LIMITS
        if (!touch) f = f or LP.FLAG_NOT_TOUCHABLE
        if (!focus) f = f or LP.FLAG_NOT_FOCUSABLE
        val p = LP(w, hh, LP.TYPE_APPLICATION_OVERLAY, f, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }
    private fun rr(c: Int, r: Float): GradientDrawable { val g = GradientDrawable(); g.setColor(c); g.cornerRadius = r; return g }
    private fun tv(s: String, sz: Float = 14f, c: Int = Color.WHITE): TextView { val t = TextView(this); t.text = s; t.textSize = sz; t.setTextColor(c); return t }
    private fun cb(n: String, bg: Int, fg: Int = Color.WHITE, pad: Int = 9): ImageView {
        val v = ImageView(this); v.setImageResource(resources.getIdentifier("ic_$n", "drawable", packageName)); v.setColorFilter(fg)
        v.setPadding(px(pad), px(pad), px(pad), px(pad))
        val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(bg); v.background = g; return v
    }
    private fun card(): LinearLayout {
        val b = LinearLayout(this); b.orientation = LinearLayout.VERTICAL; b.setPadding(px(16), px(14), px(16), px(14))
        b.background = rr(Color.parseColor("#F2111318"), px(24).toFloat()); return b
    }
    private fun lay(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)
    private fun typeName(o: JSONObject) = when (o.getString("t")) { "web" -> "web source"; "txt" -> "teks"; else -> "media" }
    private fun hl(id: String, on: Boolean) { borders[id]?.setStroke(if (on) 7 else 3, if (on) accent else Color.WHITE) }

    private fun header(title: String): LinearLayout {
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
        val b = cb("back", gray); b.setOnClickListener { back() }
        val x = cb("close", gray); x.setOnClickListener { back() }
        val t = tv(title, 17f); t.gravity = Gravity.CENTER; t.setPadding(px(20), 0, px(20), 0)
        r.addView(b, lay(px(38), px(38))); r.addView(t, lay(0, -2, 1f)); r.addView(x, lay(px(38), px(38)))
        return r
    }
    private fun place(v: View, tall: Boolean, wide: Boolean) {
        closeSheet()
        val p = if (land) lp(if (wide) (sw * 0.32f).toInt() else -2, if (tall) (sh * 0.92f).toInt() else -2, true, true).also { it.gravity = Gravity.END or Gravity.CENTER_VERTICAL; it.x = px(8) }
        else lp(if (wide) (sw * 0.94f).toInt() else -2, if (tall) (sh * 0.55f).toInt() else -2, true, true).also { it.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; it.y = px(16) }
        wm.addView(v, p); sheet = v
    }
    private fun closeSheet() { sheet?.let { wm.removeView(it) }; sheet = null }
    private fun closeDock() { dock?.let { wm.removeView(it) }; dock = null }
    private fun back() { closeSheet(); items.forEach { hl(it.getString("id"), false) }; if (edit) showDock() }

    private fun guides(v: Boolean, hz: Boolean) {
        if (v && gv == null) { val x = View(this); x.setBackgroundColor(accent); val p = lp(px(2), sh, false); p.x = sw / 2 - px(1); wm.addView(x, p); gv = x }
        if (!v && gv != null) { wm.removeView(gv); gv = null }
        if (hz && gh == null) { val x = View(this); x.setBackgroundColor(accent); val p = lp(sw, px(2), false); p.y = sh / 2 - px(1); wm.addView(x, p); gh = x }
        if (!hz && gh != null) { wm.removeView(gh); gh = null }
    }

    // ---------- bubble (garis tipis di tepi) ----------
    private fun thin(on: Boolean) {
        val b = bubble ?: return; val p = bubbleP ?: return
        if (on) { p.width = px(16); p.height = px(60); b.background = rr(accent, px(8).toFloat()); p.x = if (bubbleLeft) 0 else sw - px(16) }
        else { p.width = px(44); p.height = px(44); val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(accent); b.background = g }
        wm.updateViewLayout(b, p)
    }
    private fun makeBubble() {
        val b = View(this)
        val p = lp(px(16), px(60), true); p.y = px(150)
        bubble = b; bubbleP = p; b.alpha = 0.35f; b.background = rr(accent, px(8).toFloat())
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var free = false
        val lr = Runnable { free = true; thin(false); showTarget(); b.alpha = 1f }
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; free = false; b.alpha = 1f; h.postDelayed(lr, 450) }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) { moved = true; if (!free) h.removeCallbacks(lr) }
                    if (free) { p.x = ox + dx; p.y = oy + dy; wm.updateViewLayout(b, p) }
                    else if (moved) { p.y = (oy + dy).coerceIn(0, sh - p.height); wm.updateViewLayout(b, p) }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(lr)
                    if (free) {
                        val cx = p.x + p.width / 2; val cy = p.y + p.height / 2
                        if (abs(cx - sw / 2) < px(70) && abs(cy - (sh - px(68))) < px(70)) stopSelf()
                        else { bubbleLeft = cx < sw / 2; hideTarget(); thin(true) }
                    } else {
                        val dx = e.rawX - sx
                        if (!moved || (bubbleLeft && dx > px(20)) || (!bubbleLeft && dx < -px(20))) setEdit(!edit)
                    }
                    b.alpha = if (edit) 1f else 0.35f
                }
            }
            true
        }
        wm.addView(b, p)
    }
    private fun showTarget() {
        val t = cb("close", Color.parseColor("#DC2626"), Color.WHITE, 14)
        val p = lp(px(56), px(56), false); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(40)
        wm.addView(t, p); target = t
    }
    private fun hideTarget() { target?.let { wm.removeView(it) }; target = null }
    private fun bringBubble() { bubble?.let { wm.removeView(it); wm.addView(it, bubbleP) } }

    // ---------- widgets ----------
    private fun addWidget(o: JSONObject) {
        val id = o.getString("id")
        val root = FrameLayout(this)
        val content: View
        when (o.getString("t")) {
            "web" -> {
                val w = WebView(this); w.setBackgroundColor(0)
                w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.mediaPlaybackRequiresUserGesture = false
                w.webViewClient = WebViewClient(); w.loadUrl(o.getString("u")); content = w
            }
            "txt" -> {
                val t = TextView(this); t.text = o.getString("u"); t.setTextColor(Color.WHITE); t.gravity = Gravity.CENTER
                t.setShadowLayer(4f, 0f, 0f, Color.BLACK)
                t.setAutoSizeTextTypeUniformWithConfiguration(10, 200, 2, TypedValue.COMPLEX_UNIT_SP); content = t
            }
            else -> { val iv = ImageView(this); iv.setImageURI(Uri.parse(o.getString("u"))); content = iv }
        }
        content.alpha = o.getInt("a") / 100f
        content.visibility = if (o.optBoolean("v", true)) View.VISIBLE else View.INVISIBLE
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.rotation = o.optInt("r", 0).toFloat()
        val p = lp(o.getInt("w"), o.getInt("h"), edit); p.x = posX(o); p.y = posY(o)

        val ctl = FrameLayout(this); ctl.visibility = if (edit) View.VISIBLE else View.GONE
        val border = View(this)
        val g = GradientDrawable(); g.setColor(0x14FFFFFF); g.setStroke(3, Color.WHITE); border.background = g
        borders[id] = g; ctl.addView(border)
        val shield = View(this); ctl.addView(shield)
        val label = tv("", 13f); label.setBackgroundColor(0xAA000000.toInt()); label.visibility = View.GONE
        ctl.addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var rs = false; var mv = false
        val rrun = Runnable { rs = true; hl(id, true); label.visibility = View.VISIBLE; Toast.makeText(this, "Resize widget", Toast.LENGTH_SHORT).show() }
        shield.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; rs = false; mv = false
                    val m = px(30)
                    if (e.x < m || e.y < m || e.x > p.width - m || e.y > p.height - m) h.postDelayed(rrun, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 12 || abs(e.rawY - sy) > 12) { mv = true; if (!rs) h.removeCallbacks(rrun) }
                    if (rs) {
                        p.width = (e.rawX - p.x).toInt().coerceAtLeast(60); p.height = (e.rawY - p.y).toInt().coerceAtLeast(60)
                        label.text = "W: ${p.width}  H: ${p.height}"; wm.updateViewLayout(root, p)
                    } else if (mv) {
                        var nx = ox + (e.rawX - sx).toInt(); var ny = oy + (e.rawY - sy).toInt()
                        val sn1 = abs(nx + p.width / 2 - sw / 2) < 15; val sn2 = abs(ny + p.height / 2 - sh / 2) < 15
                        if (sn1) nx = sw / 2 - p.width / 2
                        if (sn2) ny = sh / 2 - p.height / 2
                        guides(sn1, sn2); p.x = nx; p.y = ny; wm.updateViewLayout(root, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(rrun); guides(false, false)
                    if (rs) { o.put("w", p.width).put("h", p.height); hl(id, false); label.visibility = View.GONE } else if (mv) o.put(kx(), p.x).put(ky(), p.y)
                    save()
                }
            }
            true
        }
        val sz = px(34)
        val gear = cb("gear", gray); gear.setOnClickListener { showSettings(o, false) }
        val del = cb("close", Color.parseColor("#DC2626")); del.setOnClickListener { confirmDelete(o) }
        ctl.addView(gear, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.START))
        ctl.addView(del, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END))
        root.addView(ctl)
        wm.addView(root, p); views[id] = root; params[id] = p; bringBubble()
    }
    private fun killView(id: String) {
        val v = views.remove(id) ?: return
        params.remove(id); borders.remove(id); wm.removeView(v); (v.getChildAt(0) as? WebView)?.destroy()
    }
    private fun setEdit(on: Boolean) {
        edit = on; bubble?.alpha = if (on) 1f else 0.35f
        for ((id, v) in views) {
            val p = params[id]!!
            p.flags = if (on) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
            v.getChildAt(1).visibility = if (on) View.VISIBLE else View.GONE; wm.updateViewLayout(v, p)
        }
        if (on) showDock() else { closeSheet(); closeDock() }
    }
    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        h.postDelayed({
            for (o in items) { val id = o.getString("id"); val p = params[id] ?: continue; p.x = posX(o); p.y = posY(o); wm.updateViewLayout(views[id], p) }
            bubbleP?.let { it.y = it.y.coerceIn(0, sh - px(60)) }; thin(true)
            if (sheet != null) back() else if (dock != null) showDock()
        }, 200)
    }

    // ---------- dock & sheets ----------
    private fun showDock() {
        closeDock()
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(px(6), px(6), px(6), px(6))
        r.background = rr(Color.WHITE, px(40).toFloat())
        val add = LinearLayout(this); add.gravity = Gravity.CENTER_VERTICAL; add.setPadding(px(14), px(9), px(18), px(9))
        add.background = rr(ink, px(30).toFloat()); add.setOnClickListener { showAdd() }
        add.addView(cb("plus", ink, Color.WHITE, 2), lay(px(22), px(22))); val t = tv("Add Widget", 14f); t.setPadding(px(8), 0, 0, 0); add.addView(t)
        val ly = cb("layers", Color.parseColor("#E5E7EB"), ink, 10); ly.setOnClickListener { showLayers() }
        val x = cb("close", Color.parseColor("#E5E7EB"), ink, 10); x.setOnClickListener { stopSelf() }
        r.addView(add); r.addView(ly, lay(px(40), px(40)).also { it.leftMargin = px(6) }); r.addView(x, lay(px(40), px(40)).also { it.leftMargin = px(6) })
        val p = lp(-2, -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(20)
        wm.addView(r, p); dock = r
    }
    private fun newItem(t: String, u: String): JSONObject {
        val w = if (t == "web") 450 else 400; val hh = when (t) { "web" -> 338; "txt" -> 120; else -> 300 }
        val a = minOf(sw, sh); val b = maxOf(sw, sh)
        return JSONObject().put("id", System.currentTimeMillis().toString()).put("t", t)
            .put("n", typeName(JSONObject().put("t", t)).replaceFirstChar { it.uppercase() }).put("u", u)
            .put("w", w).put("h", hh).put("a", 100).put("r", 0).put("v", true)
            .put("x0", (a - w) / 2).put("y0", (b - hh) / 2).put("x1", (b - w) / 2).put("y1", (a - hh) / 2)
    }
    private fun showAdd() {
        closeDock()
        val box = card(); box.addView(header("Add Widget"))
        val row = LinearLayout(this); row.gravity = Gravity.CENTER; row.setPadding(0, px(16), 0, px(4))
        fun opt(label: String, icon: String, act: () -> Unit) {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER; c.setPadding(px(12), 0, px(12), 0)
            c.addView(cb(icon, gray, Color.WHITE, 16), lay(px(58), px(58))); val t = tv(label, 12f); t.gravity = Gravity.CENTER; t.setPadding(0, px(6), 0, 0); c.addView(t)
            c.setOnClickListener { act() }; row.addView(c)
        }
        opt("Media", "image") {
            onPicked = { u -> h.post { showSettings(newItem("pic", u), true) } }
            startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        opt("Web Source", "globe") { showSettings(newItem("web", ""), true) }
        opt("Text", "text") { showSettings(newItem("txt", "Teks kamu"), true) }
        box.addView(row); place(box, false, false)
    }
    private fun restack() { for (o in items) { val id = o.getString("id"); val v = views[id] ?: continue; wm.removeView(v); wm.addView(v, params[id]) }; bringBubble() }

    private fun showLayers() {
        closeDock()
        val box = card(); box.addView(header("Layers"))
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        fun build() {
            list.removeAllViews()
            if (items.isEmpty()) list.addView(tv("Belum ada widget"))
            for (o in items.reversed()) {
                val id = o.getString("id")
                val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, px(5), 0, px(5)); r.tag = o
                val n = tv(o.getString("n") + "  · " + typeName(o)); n.setPadding(px(4), px(8), px(4), px(8))
                n.setOnClickListener { items.forEach { hl(it.getString("id"), false) }; hl(id, true) }
                val s = Switch(this); s.isChecked = o.optBoolean("v", true)
                s.setOnCheckedChangeListener { _, c -> o.put("v", c); views[id]?.getChildAt(0)?.visibility = if (c) View.VISIBLE else View.INVISIBLE; save() }
                val gr = cb("gear", gray); gr.setOnClickListener { showSettings(o, false) }
                val grip = cb("grip", gray); var sy = 0f
                grip.setOnTouchListener { v, e ->
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sy = e.rawY; v.parent.requestDisallowInterceptTouchEvent(true) }
                        MotionEvent.ACTION_MOVE -> r.translationY = e.rawY - sy
                        MotionEvent.ACTION_UP -> {
                            val i = list.indexOfChild(r); val ni = (i + Math.round((e.rawY - sy) / r.height)).coerceIn(0, list.childCount - 1)
                            val order = (0 until list.childCount).map { list.getChildAt(it).tag as JSONObject }.toMutableList()
                            order.removeAt(i); order.add(ni, o)
                            items.clear(); items.addAll(order.reversed()); restack(); save(); build()
                        }
                    }
                    true
                }
                r.addView(n, lay(0, -2, 1f)); r.addView(s); r.addView(gr, lay(px(34), px(34)).also { it.leftMargin = px(8) }); r.addView(grip, lay(px(34), px(34)).also { it.leftMargin = px(6) })
                list.addView(r)
            }
        }
        build()
        val sc = ScrollView(this); sc.addView(list); box.addView(sc); place(box, false, true)
    }
    private fun confirmDelete(o: JSONObject) {
        closeDock()
        val box = card()
        val extra = if (o.getString("t") == "web") " - " + o.getString("u").take(30) else ""
        val t = tv("Kamu ingin menghapus widget ${typeName(o)} - ${o.getString("n")}$extra ?", 15f); t.maxWidth = px(300); t.setPadding(0, 0, 0, px(12))
        val row = LinearLayout(this)
        val no = Button(this); no.text = "Batal"; no.setOnClickListener { back() }
        val yes = Button(this); yes.text = "Hapus"; yes.setOnClickListener { killView(o.getString("id")); items.remove(o); save(); back() }
        row.addView(no, lay(0, -2, 1f)); row.addView(yes, lay(0, -2, 1f))
        box.addView(t); box.addView(row); place(box, false, false)
    }

    private fun showSettings(o: JSONObject, isNew: Boolean) {
        closeDock()
        val t = o.getString("t")
        fun et(v: String, text: Boolean = false): EditText {
            val e = EditText(this); e.setText(v); e.setTextColor(Color.WHITE); e.setHintTextColor(0x88FFFFFF.toInt()); e.textSize = 14f
            e.inputType = if (text) InputType.TYPE_CLASS_TEXT else (InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED); return e
        }
        val form = LinearLayout(this); form.orientation = LinearLayout.VERTICAL
        fun sl(label: String, mn: Int, mx: Int, v: Int): EditText {
            val e = et(v.toString()); val s = SeekBar(this); s.max = mx - mn; s.progress = (v - mn).coerceIn(0, mx - mn)
            var lock = false
            s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { lock = true; e.setText((p + mn).toString()); lock = false } }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(x: Editable?) { if (!lock) e.text.toString().toIntOrNull()?.let { s.progress = (it - mn).coerceIn(0, mx - mn) } }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
            })
            val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(tv(label, 13f), lay(px(70), -2)); r.addView(s, lay(0, -2, 1f)); r.addView(e, lay(px(70), -2))
            form.addView(r); return e
        }
        val name = et(o.getString("n"), true); val url = et(o.getString("u"), true); url.hint = "https://..."
        form.addView(tv("Nama", 12f)); form.addView(name)
        if (t != "pic") { form.addView(tv(if (t == "web") "Link URL" else "Teks", 12f)); form.addView(url) }
        val big = maxOf(sw, sh)
        form.addView(tv("Position", 14f))
        val fx = sl("X", -sw, big, posX(o)); val fy = sl("Y", -sh, big, posY(o))
        form.addView(tv("Scale", 14f))
        val fw = sl("W", 60, big, o.getInt("w")); val fh = sl("H", 60, big, o.getInt("h"))
        form.addView(tv("Rotate", 14f))
        val fr = sl("°", -180, 180, o.optInt("r", 0))
        form.addView(tv("Alignment", 14f))
        val icons = arrayOf("↖", "↑", "↗", "←", "●", "→", "↙", "↓", "↘")
        for (ay in 0..2) {
            val r = LinearLayout(this); r.gravity = Gravity.CENTER
            for (ax in 0..2) {
                val b = tv(icons[ay * 3 + ax], 16f); b.gravity = Gravity.CENTER; b.background = rr(gray, px(12).toFloat())
                b.setOnClickListener {
                    val w = fw.text.toString().toIntOrNull() ?: 100; val hh = fh.text.toString().toIntOrNull() ?: 100
                    fx.setText(((sw - w) * ax / 2).toString()); fy.setText(((sh - hh) * ay / 2).toString())
                }
                r.addView(b, lay(px(44), px(40)).also { it.setMargins(px(4), px(3), px(4), px(3)) })
            }
            form.addView(r)
        }
        form.addView(tv("Transparansi (kanan = jelas)", 12f))
        val seek = SeekBar(this); seek.max = 100; seek.progress = o.getInt("a"); form.addView(seek)
        val btns = LinearLayout(this)
        val cancel = Button(this); cancel.text = "Batal"; cancel.setOnClickListener { back() }
        val ok = Button(this); ok.text = "OK"
        ok.setOnClickListener {
            var u = url.text.toString().trim()
            if (t != "pic") {
                if (u.isEmpty()) { Toast.makeText(this, "Isi dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (t == "web" && !u.startsWith("http")) u = "https://$u"
                o.put("u", u)
            }
            o.put("n", name.text.toString())
            o.put(kx(), fx.text.toString().toIntOrNull() ?: 0).put(ky(), fy.text.toString().toIntOrNull() ?: 0)
            o.put("w", (fw.text.toString().toIntOrNull() ?: 400).coerceAtLeast(60)).put("h", (fh.text.toString().toIntOrNull() ?: 300).coerceAtLeast(60))
            o.put("r", fr.text.toString().toIntOrNull() ?: 0).put("a", seek.progress.coerceAtLeast(10))
            if (isNew) items.add(o) else killView(o.getString("id"))
            addWidget(o); save(); back()
        }
        btns.addView(cancel, lay(0, -2, 1f)); btns.addView(ok, lay(0, -2, 1f))
        val box = card(); box.addView(header("Widget Settings"))
        val sc = ScrollView(this); sc.addView(form); box.addView(sc, lay(-1, 0, 1f)); box.addView(btns)
        place(box, true, true)
    }

    override fun onDestroy() {
        views.keys.toList().forEach { killView(it) }
        bubble?.let { wm.removeView(it) }
        closeSheet(); closeDock(); hideTarget(); guides(false, false)
        super.onDestroy()
    }
}
