package com.example.overlaystudio

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.accessibilityservice.AccessibilityService
import android.app.*
import android.view.accessibility.AccessibilityEvent
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.view.animation.LinearInterpolator
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import kotlin.math.abs
import org.json.JSONArray
import org.json.JSONObject

class OverlayService : AccessibilityService() {
    companion object { var onPicked: ((String) -> Unit)? = null; var instance: OverlayService? = null }

    private lateinit var wm: WindowManager
    private val items = mutableListOf<JSONObject>()
    private val views = mutableMapOf<String, FrameLayout>()
    private val params = mutableMapOf<String, LP>()
    private val borders = mutableMapOf<String, GradientDrawable>()
    private var edit = false
    private var bubble: View? = null
    private var bubbleP: LP? = null
    private var bubbleLeft = true
    private var dock: View? = null
    private var sheet: View? = null
    private var target: View? = null
    private var gv: View? = null
    private var gh: View? = null
    private var arrow: View? = null
    private var peek = false
    private var galpha = 80
    private var dock2: View? = null
    private val anims = mutableMapOf<String, Animator>()
    private val h = Handler(Looper.getMainLooper())
    private val d: Float get() = resources.displayMetrics.density
    private fun dm(): DisplayMetrics { val m = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m); return m }
    private val sw: Int get() = dm().widthPixels
    private val sh: Int get() = dm().heightPixels
    private val land: Boolean get() = sw > sh
    private val accent = Color.parseColor("#2563EB")
    private val gray = Color.parseColor("#374151")
    private val ink = Color.parseColor("#111111")

    private var active = false
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() {
        super.onServiceConnected(); instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (getSharedPreferences("p", 0).getBoolean("on", true)) start()
    }
    fun start() {
        if (active) return
        active = true; edit = false; peek = false
        getSharedPreferences("p", 0).edit().putBoolean("on", true).apply()
        galpha = getSharedPreferences("p", 0).getInt("galpha2", 100)
        items.clear()
        val arr = JSONArray(getSharedPreferences("p", 0).getString("items", "[]"))
        for (i in 0 until arr.length()) items.add(arr.getJSONObject(i))
        items.forEach { addWidget(it) }
        makeBubble()
    }
    fun shutdown(user: Boolean = true) {
        if (!active) return
        if (user) getSharedPreferences("p", 0).edit().putBoolean("on", false).apply()
        active = false; edit = false; peek = false
        views.keys.toList().forEach { killView(it) }
        bubble?.let { wm.removeView(it) }; bubble = null
        refreshLocks(); hideExpr(); closeSheet(); closeDock(); hideTarget(); hideArrow(); guides(false, false)
        items.clear()
    }

    // ---------- helpers ----------
    private fun gesture() = try { android.provider.Settings.Secure.getInt(contentResolver, "navigation_mode", 0) == 2 } catch (e: Exception) { false }
    private fun navSize(): Int { val id = resources.getIdentifier(if (land) "navigation_bar_width" else "navigation_bar_height", "dimen", "android"); return if (id > 0) resources.getDimensionPixelSize(id) else 0 }
    private fun navB() = if (gesture() || land) 0 else navSize()
    @Suppress("DEPRECATION")
    private fun navR() = if (land && !gesture() && wm.defaultDisplay.rotation == Surface.ROTATION_90) navSize() else 0
    private fun px(v: Int) = (v * d).toInt()
    private fun kx() = if (land) "x1" else "x0"
    private fun ky() = if (land) "y1" else "y0"
    private fun posX(o: JSONObject) = o.optInt(kx(), (sw - o.getInt("w")) / 2)
    private fun posY(o: JSONObject) = o.optInt(ky(), (sh - o.getInt("h")) / 2)
    private fun save() { getSharedPreferences("p", 0).edit().putString("items", JSONArray(items).toString()).apply() }
    private fun lp(w: Int, hh: Int, touch: Boolean, focus: Boolean = false): LP {
        var f = LP.FLAG_LAYOUT_NO_LIMITS or LP.FLAG_HARDWARE_ACCELERATED
        if (!touch) f = f or LP.FLAG_NOT_TOUCHABLE
        if (!focus) f = f or LP.FLAG_NOT_FOCUSABLE
        val p = LP(w, hh, LP.TYPE_ACCESSIBILITY_OVERLAY, f, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        return p
    }
    private fun rr(c: Int, r: Float): GradientDrawable { val g = GradientDrawable(); g.setColor(c); g.cornerRadius = r; return g }
    private fun tv(s: String, sz: Float = 14f, c: Int = Color.WHITE): TextView { val t = TextView(this); t.text = s; t.textSize = sz; t.setTextColor(c); return t }
    private fun cb(n: String, bg: Int, fg: Int = Color.WHITE, pad: Int = 9): ImageView {
        val v = ImageView(this); v.setImageResource(resources.getIdentifier("ic_$n", "drawable", packageName)); v.setColorFilter(fg)
        v.setPadding(px(pad), px(pad), px(pad), px(pad))
        val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(bg); v.background = g; return v
    }
    private inner class SheetBox(c: android.content.Context) : LinearLayout(c) {
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) {
                    val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                    if (!imm.hideSoftInputFromWindow(windowToken, 0)) back()
                }
                return true
            }
            return super.dispatchKeyEvent(e)
        }
    }
    private fun card(): LinearLayout {
        val b = SheetBox(this); b.orientation = LinearLayout.VERTICAL; b.setPadding(px(16), px(14), px(16), px(14))
        b.background = rr(Color.parseColor("#F2111318"), px(24).toFloat()); return b
    }
    private fun lay(w: Int, hh: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, hh, wt)
    private fun typeName(o: JSONObject) = when (o.getString("t")) { "web" -> "web source"; "txt" -> "teks"; "vt" -> "pngtuber"; "xp" -> "panel"; else -> "media" }
    private fun hl(id: String, on: Boolean) { borders[id]?.setStroke(if (on) 7 else 3, if (on) accent else if (locked(id)) 0x55FFFFFF else Color.WHITE) }

    private fun header(title: String): LinearLayout {
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
        val b = cb("back", gray); b.setOnClickListener { back() }
        val x = cb("close", gray); x.setOnClickListener { back() }
        val t = tv(title, 17f); t.gravity = Gravity.CENTER; t.setPadding(px(20), 0, px(20), 0)
        r.addView(b, lay(px(38), px(38))); r.addView(t, lay(0, -2, 1f)); r.addView(x, lay(px(38), px(38)))
        return r
    }
    private fun place(v: View, tall: Boolean, wide: Boolean) {
        closeSheet()
        val p = if (land) lp(if (wide) (sw * 0.32f).toInt() else -2, if (tall) (sh * 0.92f).toInt() else -2, true, true).also { it.gravity = Gravity.END or Gravity.CENTER_VERTICAL; it.x = px(8) + navR() }
        else lp(if (wide) (sw * 0.94f).toInt() else -2, if (tall) (sh * 0.55f).toInt() else -2, true, true).also { it.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; it.y = px(16) + navB() }
        wm.addView(v, p); sheet = v
        v.scaleX = 0.9f; v.scaleY = 0.9f; v.alpha = 0f; v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
    }
    private fun closeSheet() { sheet?.let { wm.removeView(it) }; sheet = null }
    private fun closeDock() { dock?.let { wm.removeView(it) }; dock = null; dock2?.let { wm.removeView(it) }; dock2 = null }
    private fun back() { save(); closeSheet(); items.forEach { hl(it.getString("id"), false) }; if (edit) showDock() }

    private fun guides(v: Boolean, hz: Boolean) {
        if (v && gv == null) { val x = View(this); x.setBackgroundColor(accent); val p = lp(px(2), sh, false); p.x = sw / 2 - px(1); wm.addView(x, p); gv = x }
        if (!v && gv != null) { wm.removeView(gv); gv = null }
        if (hz && gh == null) { val x = View(this); x.setBackgroundColor(accent); val p = lp(sw, px(2), false); p.y = sh / 2 - px(1); wm.addView(x, p); gh = x }
        if (!hz && gh != null) { wm.removeView(gh); gh = null }
    }

    // ---------- bubble ----------
    private fun thin(on: Boolean) {
        val b = bubble ?: return; val p = bubbleP ?: return
        if (on) { p.width = px(16); p.height = px(60); b.background = rr(accent, px(8).toFloat()) }
        else { p.width = px(44); p.height = px(44); val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(accent); b.background = g }
        wm.updateViewLayout(b, p)
    }
    private fun snapBubble() {
        val p = bubbleP ?: return
        p.y = p.y.coerceIn(px(40), sh - px(130) - navB()); p.x = if (bubbleLeft) px(2) else sw - px(18) - navR()
        thin(true)
    }
    private fun makeBubble() {
        val b = View(this)
        val p = lp(px(16), px(60), true); p.y = px(150); p.x = px(2)
        bubble = b; bubbleP = p; b.alpha = 0.35f; b.background = rr(accent, px(8).toFloat())
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var circle = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false; circle = false; b.alpha = 1f }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        p.x = ox + dx; p.y = oy + dy
                        val far = minOf(p.x + p.width / 2, sw - p.x - p.width / 2) > px(70)
                        if (far && !circle) { circle = true; thin(false); showTarget() }
                        else if (!far && circle) { circle = false; hideTarget(); thin(true) }
                        wm.updateViewLayout(b, p)
                        target?.let { val n = nearTarget(e.rawX, e.rawY); it.scaleX = if (n) 1.3f else 1f; it.scaleY = it.scaleX }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) { if (edit) setEdit(false) else setPeek(!peek) }
                    else {
                        val cx = p.x + p.width / 2; val cy = p.y + p.height / 2
                        if (nearTarget(e.rawX, e.rawY)) shutdown()
                        else { bubbleLeft = cx < sw / 2; hideTarget(); snapBubble() }
                    }
                    b.alpha = if (edit || peek) 1f else 0.35f
                }
            }
            true
        }
        wm.addView(b, p)
    }
    private fun showTarget() {
        val t = cb("close", Color.parseColor("#DC2626"), Color.WHITE, 14)
        val p = lp(px(56), px(56), false); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(95) + navB()
        wm.addView(t, p); target = t
    }
    private fun nearTarget(x: Float, y: Float): Boolean {
        val t = target ?: return false; val loc = IntArray(2); t.getLocationOnScreen(loc)
        return abs(x - (loc[0] + t.width / 2f)) < px(80) && abs(y - (loc[1] + t.height / 2f)) < px(80)
    }
    private fun hideTarget() { target?.let { wm.removeView(it) }; target = null }
    private fun bringBubble() { bubble?.let { wm.removeView(it); wm.addView(it, bubbleP) } }
    private fun showArrow() {
        hideArrow()
        val a = FrameLayout(this); a.background = rr(ink, px(12).toFloat()); a.alpha = 0.3f
        val i = ImageView(this); i.setImageResource(resources.getIdentifier("ic_up", "drawable", packageName)); i.setColorFilter(Color.WHITE)
        i.setPadding(px(8), px(8), px(8), px(8)); a.addView(i)
        a.setOnClickListener { setPeek(false); setEdit(true) }
        val p = lp(px(44), px(44), true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(28) + navB()
        wm.addView(a, p); arrow = a
    }
    private fun hideArrow() { arrow?.let { wm.removeView(it) }; arrow = null }
    private fun setPeek(on: Boolean) {
        peek = on; bubble?.alpha = if (on || edit) 1f else 0.35f
        ctlMode(0)
        for ((id, v) in views) {
            val p = params[id] ?: continue
            p.flags = if (isXp(id) || inter(id)) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
            p.alpha = if (on) 1f else galpha / 100f
            wm.updateViewLayout(v, p)
        }
        if (on) showArrow() else hideArrow()
        hideExpr()
    }

    // ---------- widgets ----------
    private fun videoView(o: JSONObject): View {
        val tx = TextureView(this)
        var mp: MediaPlayer? = null
        var vw = 0; var vh = 0
        fun fit() {
            if (vw == 0 || vh == 0 || tx.width == 0 || tx.height == 0) return
            val va = vw.toFloat() / vh; val ra = tx.width.toFloat() / tx.height
            val sx = if (va > ra) 1f else va / ra; val sy = if (va > ra) ra / va else 1f
            val mx = android.graphics.Matrix(); mx.setScale(sx, sy, tx.width / 2f, tx.height / 2f); tx.setTransform(mx)
        }
        tx.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, hh: Int) {
                try {
                    val m = MediaPlayer(); mp = m
                    m.setDataSource(this@OverlayService, Uri.parse(o.getString("u")))
                    m.setSurface(Surface(st)); m.isLooping = true
                    val vol = if (o.optBoolean("snd", false)) 1f else 0f; m.setVolume(vol, vol)
                    m.setOnVideoSizeChangedListener { _, w2, h2 -> vw = w2; vh = h2; fit() }; m.setOnPreparedListener { it.start() }; m.prepareAsync()
                } catch (e: Exception) {}
            }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { mp?.release(); mp = null; return true }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, hh: Int) { fit() }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        return tx
    }
    private fun loadBmp(u: Uri): Bitmap {
        val o1 = BitmapFactory.Options(); o1.inJustDecodeBounds = true
        contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o1) }
        var ss = 1; while (o1.outWidth / ss > 1200 || o1.outHeight / ss > 1200) ss *= 2
        val o2 = BitmapFactory.Options(); o2.inSampleSize = ss
        return contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o2)!! }
    }
    private fun shadowed(b: Bitmap, r: Int): Bitmap {
        val rad = r * 2f; val pad = (rad * 2).toInt() + 2
        val out = Bitmap.createBitmap(b.width + pad * 2, b.height + pad * 2, Bitmap.Config.ARGB_8888); val c = Canvas(out)
        val pt = Paint(); pt.maskFilter = BlurMaskFilter(rad, BlurMaskFilter.Blur.NORMAL)
        val off = IntArray(2); val a = b.extractAlpha(pt, off)
        val bp = Paint(); bp.color = Color.BLACK
        c.drawBitmap(a, (pad + off[0]).toFloat(), (pad + off[1]).toFloat(), bp)
        c.drawBitmap(b, pad.toFloat(), pad.toFloat(), null)
        return out
    }
    private val vtMap = mutableMapOf<String, VT>()
    private val lockBtns = mutableMapOf<String, View>()
    private var exprP: View? = null

    private inner class VT(val o: JSONObject, val iv: ImageView, val tw: FrameLayout) {
        val bm = HashMap<String, Bitmap?>(); val dr = HashMap<String, android.graphics.drawable.Drawable?>()
        var cur = 0; var forced = -1; var blink = false; var lastTalk = 0L; var running = true; var gen = 0
        var anim: Animator? = null; var meter: ((Int) -> Unit)? = null; var calibEnd = 0L; var calibMax = 0
        val sl: JSONArray get() = o.getJSONArray("sl")
        fun img(u: String): Bitmap? = if (u.isEmpty()) null else bm.getOrPut(u) { try { loadBmp(Uri.parse(u)) } catch (e: Exception) { null } }
        fun show(u: String): Boolean {
            if (Build.VERSION.SDK_INT < 28 || u.isEmpty()) return false
            val m = try { contentResolver.getType(Uri.parse(u)) ?: "" } catch (e: Exception) { "" }
            if (m != "image/gif" && m != "image/webp") return false
            val d = dr.getOrPut(u) { try { ImageDecoder.decodeDrawable(ImageDecoder.createSource(contentResolver, Uri.parse(u))) } catch (e: Exception) { null } } ?: return false
            iv.setImageDrawable(d); if (d is AnimatedImageDrawable) { d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; d.start() }; return true
        }
        val tx = TextureView(this@OverlayService)
        var mp: MediaPlayer? = null; var surf: Surface? = null; var curVideo = ""; var vw = 0; var vh = 0
        val ckCache = HashMap<String, Bitmap>()
        fun fitV() {
            if (vw == 0 || vh == 0 || tx.width == 0 || tx.height == 0) return
            val va = vw.toFloat() / vh; val ra = tx.width.toFloat() / tx.height
            val m = android.graphics.Matrix(); m.setScale(if (va > ra) 1f else va / ra, if (va > ra) ra / va else 1f, tx.width / 2f, tx.height / 2f); tx.setTransform(m)
        }
        fun play(u: String) {
            val sf = surf ?: return
            try {
                mp?.release(); val m = MediaPlayer(); mp = m
                m.setDataSource(this@OverlayService, Uri.parse(u)); m.setSurface(sf); m.isLooping = true; m.setVolume(0f, 0f)
                m.setOnVideoSizeChangedListener { _, w2, h2 -> vw = w2; vh = h2; fitV() }
                m.setOnPreparedListener { it.start() }; m.prepareAsync()
            } catch (e: Exception) {}
        }
        var ckOn = false; var ckKey = ""; var ckStr = 50
        var dest: Bitmap? = null; var pix: IntArray? = null; var outBm: Bitmap? = null
        val ckR: Runnable = object : Runnable {
            override fun run() {
                if (!running || !ckOn) return
                try {
                    if (vw > 0 && vh > 0 && tx.isAvailable) {
                        val sc = minOf(1f, 640f / maxOf(vw, vh)); val bw = (vw * sc).toInt().coerceAtLeast(2); val bh = (vh * sc).toInt().coerceAtLeast(2)
                        var d = dest; if (d == null || d.width != bw || d.height != bh) { d = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); dest = d; pix = IntArray(bw * bh); outBm = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888) }
                        tx.getBitmap(d); val p = pix!!; d.getPixels(p, 0, bw, 0, 0, bw, bh)
                        for (i in p.indices) { val c = p[i]; if (keyHit(ckKey, ckStr, (c shr 16) and 255, (c shr 8) and 255, c and 255)) p[i] = 0 }
                        val ob = outBm!!; ob.setPixels(p, 0, bw, 0, 0, bw, bh); iv.setImageBitmap(null); iv.setImageBitmap(ob)
                    }
                } catch (e: Exception) {}
                h.postDelayed(this, 66)
            }
        }
        init {
            tw.addView(tx, FrameLayout.LayoutParams(-1, -1)); tx.alpha = 0f
            tx.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, hh: Int) { surf = Surface(st); if (curVideo.isNotEmpty()) play(curVideo) }
                override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { mp?.release(); mp = null; surf = null; return true }
                override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, hh: Int) { fitV() }
                override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
            }
        }
        fun render() {
            val s = sl.getJSONObject(cur.coerceIn(0, sl.length() - 1))
            val bu = if (blink) s.optString("bu", "") else ""
            val u = if (bu.isNotEmpty()) bu else s.optString("u", "").ifEmpty { sl.getJSONObject(0).optString("u", "") }
            val m = try { if (u.isEmpty()) "" else contentResolver.getType(Uri.parse(u)) ?: "" } catch (e: Exception) { "" }
            if (m.startsWith("video/")) {
                val ck = s.optString("ck", ""); ckKey = ck; ckStr = s.optInt("cs", 50)
                if (ck.isEmpty()) { ckOn = false; iv.alpha = 0f; tx.alpha = 1f }
                else { tx.alpha = 0.01f; iv.alpha = 1f; if (!ckOn) { ckOn = true; h.post(ckR) } }
                if (curVideo != u) { curVideo = u; play(u) }
            } else {
                ckOn = false; tx.alpha = 0f; iv.alpha = 1f
                if (curVideo.isNotEmpty()) { curVideo = ""; mp?.release(); mp = null }
                if (!show(u)) {
                    val b0 = img(u); val ck = s.optString("ck", ""); val cs = s.optInt("cs", 50)
                    iv.setImageBitmap(if (b0 != null && ck.isNotEmpty()) ckCache.getOrPut("$u$ck$cs") { chroma(b0, ck, cs) } else b0)
                }
            }
        }
        fun trans(i: Int) {
            val s = sl.getJSONObject(i); val k = s.optString("tr", "").ifEmpty { o.optString("tr", "pop") }
            val z = o.optInt("ts", 15) / 100f; val d = o.optInt("td", 250).toLong()
            when (k) {
                "pop" -> { tw.scaleX = 1f + z; tw.scaleY = 1f + z; tw.animate().scaleX(1f).scaleY(1f).setDuration(d).start() }
                "shake" -> ObjectAnimator.ofFloat(tw, "translationX", 0f, -z * tw.width * 0.3f, z * tw.width * 0.3f, -z * tw.width * 0.2f, 0f).setDuration(d).start()
                "jump" -> ObjectAnimator.ofFloat(tw, "translationY", 0f, -z * tw.height, 0f).setDuration(d).start()
                "fade" -> { tw.alpha = 0.3f; tw.animate().alpha(1f).setDuration(d).start() }
            }
        }
        fun set(i: Int) { if (i != cur) { cur = i; render(); trans(i) } }
        val ret = Runnable { forced = -1; set(0) }
        fun force(i: Int) { forced = i; set(i); h.removeCallbacks(ret); val rt = o.optInt("rt", 3); if (rt > 0) h.postDelayed(ret, rt * 1000L) }
        val blinkR: Runnable = object : Runnable {
            override fun run() {
                if (!running) return
                if (o.optBoolean("bk", true)) { blink = true; render(); h.postDelayed({ blink = false; render() }, o.optInt("bd", 200).toLong()) }
                h.postDelayed(this, (o.optInt("bi", 4) * 1000L * (0.6 + Math.random() * 0.8)).toLong())
            }
        }
        fun onLevel(l: Int) {
            meter?.invoke(l)
            val now = System.currentTimeMillis()
            if (now < calibEnd) calibMax = maxOf(calibMax, l)
            if (forced >= 0) return
            var pick = 0; var best = -1
            for (i in 1 until sl.length()) { val s = sl.getJSONObject(i); val th = s.optInt("th", 30); if (s.optBoolean("tk") && l >= th && th > best) { best = th; pick = i } }
            if (pick != 0) { lastTalk = now; set(pick) } else if (now - lastTalk > o.optInt("hl", 250)) set(0)
        }
        fun applyMode() { gen++; if (o.optString("md", "man") == "mic") startMic() else set(0) }
        fun startMic() {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this@OverlayService, "Izin mikrofon belum diberikan", Toast.LENGTH_LONG).show(); return
            }
            gen++; val g = gen
            Thread {
                try {
                    val rate = 16000; val bs = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    val ar = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bs * 2)
                    ar.startRecording(); val buf = ShortArray(bs / 2); var silent = 0
                    while (running && g == gen) {
                        val n = ar.read(buf, 0, buf.size); if (n <= 0) continue
                        var sum = 0.0; for (k in 0 until n) sum += buf[k] * buf[k].toDouble()
                        val rms = Math.sqrt(sum / n)
                        if (rms < 1.0) silent++ else silent = 0
                        if (silent == 80) h.post { Toast.makeText(this@OverlayService, "Mic tidak menangkap suara (mungkin dipakai aplikasi lain)", Toast.LENGTH_LONG).show() }
                        val lvl = ((20 * Math.log10((rms + 1) / 32768.0) + 60) / 60 * 100).coerceIn(0.0, 100.0).toInt()
                        h.post { if (g == gen) onLevel(lvl) }
                    }
                    ar.stop(); ar.release()
                } catch (e: Exception) {}
            }.start()
        }
        fun start() {
            render(); iv.rotationY = if (o.optBoolean("fl", false)) 180f else 0f
            h.postDelayed(blinkR, 2000)
            val mo = o.optString("mo", "breath"); val sp = o.optInt("mp", 3).coerceAtLeast(1); val ma = o.optInt("ma", 5).coerceAtLeast(1)
            if (mo != "none") iv.post {
                val hh = iv.height.toFloat()
                val a = when (mo) {
                    "sway" -> ObjectAnimator.ofFloat(iv, "rotation", -ma.toFloat(), ma.toFloat())
                    "pulse" -> ObjectAnimator.ofPropertyValuesHolder(iv, PropertyValuesHolder.ofFloat("scaleX", 1f, 1f + ma / 100f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1f + ma / 100f))
                    else -> ObjectAnimator.ofFloat(iv, "translationY", 0f, -hh * ma / 100f)
                }
                a.duration = (2400L / sp).coerceAtLeast(250); a.repeatCount = ValueAnimator.INFINITE; a.repeatMode = ValueAnimator.REVERSE; a.start(); anim = a
            }
            if (o.optString("md", "man") == "mic") startMic()
        }
        fun stop() { running = false; gen++; h.removeCallbacks(blinkR); h.removeCallbacks(ret); anim?.cancel(); ckOn = false; h.removeCallbacks(ckR); mp?.release(); mp = null }
    }
    private fun keyHit(key: String, st: Int, r: Int, g: Int, bl: Int): Boolean = when (key) {
        "g" -> g - maxOf(r, bl) > 110 - st; "b" -> bl - maxOf(r, g) > 110 - st
        "k" -> maxOf(r, maxOf(g, bl)) < st * 3 / 2; "w" -> minOf(r, minOf(g, bl)) > 255 - st * 3 / 2; else -> false
    }
    private fun chroma(b: Bitmap, key: String, st: Int): Bitmap {
        val w = b.width; val hh = b.height; val p = IntArray(w * hh); b.getPixels(p, 0, w, 0, 0, w, hh)
        val thr = 110 - st
        for (i in p.indices) {
            val c = p[i]; val r = (c shr 16) and 255; val g = (c shr 8) and 255; val bl = c and 255
            val hit = when (key) { "g" -> g - maxOf(r, bl) > thr; "b" -> bl - maxOf(r, g) > thr; "k" -> maxOf(r, maxOf(g, bl)) < st * 3 / 2; "w" -> minOf(r, minOf(g, bl)) > 255 - st * 3 / 2; else -> false }
            if (hit) p[i] = 0
        }
        val out = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888); out.setPixels(p, 0, w, 0, 0, w, hh); return out
    }
    private val xpRoot = mutableMapOf<String, FrameLayout>()
    private fun inter(id: String) = items.firstOrNull { it.getString("id") == id }?.optBoolean("ia", false) ?: false
    private fun isXp(id: String) = items.firstOrNull { it.getString("id") == id }?.getString("t") == "xp"
    private fun touchFor(id: String, ed: Boolean) = if (isXp(id) || inter(id)) !(ed && locked(id)) else ed && !locked(id)
    private fun makeVt(o: JSONObject, id: String): View {
        val iv = ImageView(this); iv.scaleType = ImageView.ScaleType.FIT_CENTER
        val tw = FrameLayout(this); tw.addView(iv, FrameLayout.LayoutParams(-1, -1))
        val vt = VT(o, iv, tw); vtMap[id] = vt; vt.start(); return tw
    }
    private fun makeXp(o: JSONObject, id: String): View {
        val root = FrameLayout(this); xpRoot[id] = root; fillXp(o, root); return root
    }
    private fun fillXp(o: JSONObject, root: FrameLayout) {
        root.removeAllViews()
        val vo = items.firstOrNull { it.getString("id") == o.optString("vid") } ?: return
        val vt = vtMap[vo.getString("id")]
        val auto = vo.optString("md", "man") == "mic"
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        val mb = tv(if (auto) "Auto" else "Manual", 13f); mb.gravity = Gravity.CENTER; mb.setPadding(px(12), px(8), px(12), px(8))
        mb.background = rr(if (auto) accent else gray, px(12).toFloat())
        mb.setOnClickListener {
            o.put(if (auto) "wa" else "wm", o.getInt("w")).put(if (auto) "ha" else "hm", o.getInt("h"))
            vo.put("md", if (auto) "man" else "mic"); val na = !auto
            o.put("w", o.optInt(if (na) "wa" else "wm", if (na) 150 else 360)).put("h", o.optInt(if (na) "ha" else "hm", if (na) 56 else 150))
            save(); relayout(o); vt?.applyMode(); refreshXp()
        }
        col.addView(mb, lay(-1, -2).also { it.setMargins(px(3), px(3), px(3), px(3)) })
        if (!auto) {
            val sl = vo.getJSONArray("sl")
            val cols = if (o.optInt("cols", 0) > 0) o.optInt("cols") else maxOf(1, o.getInt("w") / px(96))
            var row: LinearLayout? = null
            for (i in 0 until sl.length()) {
                if (i % cols == 0) { row = LinearLayout(this); col.addView(row) }
                val sj = sl.getJSONObject(i)
                val b = tv(sj.optString("em", "").ifEmpty { sj.optString("n", "?") }, 12f); b.gravity = Gravity.CENTER; b.setPadding(px(8), px(10), px(8), px(10))
                val g = rr(if (sj.optInt("bc", 0) != 0) sj.optInt("bc") else gray, px(12).toFloat()); if (vt != null && vt.cur == i) g.setStroke(3, accent); b.background = g
                b.setOnClickListener { vt?.force(i); refreshXp() }
                row!!.addView(b, lay(0, -2, 1f).also { it.setMargins(px(3), px(3), px(3), px(3)) })
            }
        }
        root.addView(col, FrameLayout.LayoutParams(-1, -2))
    }
    private fun refreshXp() { for ((id, r) in xpRoot) { val o = items.firstOrNull { it.getString("id") == id } ?: continue; fillXp(o, r) } }
    private fun ensureXp(vo: JSONObject) {
        val vid = vo.getString("id")
        if (items.any { it.optString("vid") == vid }) return
        val a = minOf(sw, sh); val b = maxOf(sw, sh)
        val o = JSONObject().put("id", (System.currentTimeMillis() + 1).toString()).put("t", "xp").put("n", "Panel ekspresi").put("u", "").put("vid", vid)
            .put("w", 360).put("h", 150).put("a", 100).put("r", 0).put("v", true).put("cols", 0)
            .put("x0", (a - 360) / 2).put("y0", b - 380).put("x1", (b - 360) / 2).put("y1", a - 200)
        items.add(o); addWidget(o); save()
    }
    private fun newVt(): JSONObject {
        val a = minOf(sw, sh); val b = maxOf(sw, sh)
        val sl = JSONArray().put(JSONObject().put("n", "Diam").put("u", "")).put(JSONObject().put("n", "Bicara").put("u", "").put("tk", true).put("th", 30))
        return JSONObject().put("id", System.currentTimeMillis().toString()).put("t", "vt").put("n", "PNGTuber").put("u", "")
            .put("w", 400).put("h", 400).put("a", 100).put("r", 0).put("v", true).put("sl", sl)
            .put("md", "man").put("bk", true).put("bi", 4).put("mo", "breath").put("mp", 3).put("fl", false).put("rt", 3)
            .put("x0", (a - 400) / 2).put("y0", (b - 400) / 2).put("x1", (b - 400) / 2).put("y1", (a - 400) / 2)
    }
    private fun hideExpr() { exprP?.let { wm.removeView(it) }; exprP = null }
    private fun showExpr() {
        hideExpr()
        val o = items.firstOrNull { it.getString("t") == "vt" } ?: return
        val vt = vtMap[o.getString("id")] ?: return
        val sl = o.getJSONArray("sl")
        val box = LinearLayout(this); box.orientation = LinearLayout.VERTICAL; box.setPadding(px(8), px(8), px(8), px(8))
        box.background = rr(Color.parseColor("#E6111318"), px(18).toFloat())
        var row: LinearLayout? = null
        for (i in 0 until sl.length()) {
            if (i % 4 == 0) { row = LinearLayout(this); box.addView(row) }
            val b = tv(sl.getJSONObject(i).optString("n", "?"), 12f); b.gravity = Gravity.CENTER; b.setPadding(px(12), px(10), px(12), px(10))
            val g = rr(gray, px(12).toFloat()); if (vt.cur == i) g.setStroke(3, accent); b.background = g
            b.setOnClickListener { vt.force(i); showExpr() }
            row!!.addView(b, lay(-2, -2).also { it.setMargins(px(3), px(3), px(3), px(3)) })
        }
        val p = lp(-2, -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(84) + navB()
        wm.addView(box, p); exprP = box
    }
    private fun refreshLocks() {
        lockBtns.values.forEach { wm.removeView(it) }; lockBtns.clear()
        if (!edit) return
        for (o in items) {
            if (!o.optBoolean("lk", false)) continue
            val id = o.getString("id"); val p = params[id] ?: continue
            val b = cb("lock", accent); val sz = px(30)
            b.setOnClickListener { setLock(o, false) }
            val q = lp(sz, sz, true); q.x = p.x + p.width - sz - px(2); q.y = p.y + px(2)
            wm.addView(b, q); lockBtns[id] = b
        }
    }
    private fun showVtPanel(o: JSONObject, isNew: Boolean) {
        closeDock(); closeSheet()
        val id = o.getString("id")
        if (!items.contains(o)) { items.add(o); addWidget(o) }
        fun reload() { killView(id); addWidget(o); restack(); save() }
        val box = card(); box.addView(header("PNGTuber"))
        val form = LinearLayout(this); form.orientation = LinearLayout.VERTICAL
        fun chip(lb: String, act: () -> Unit): TextView { val c = tv(lb, 13f); c.setPadding(px(12), px(7), px(12), px(7)); c.background = rr(gray, px(14).toFloat()); c.setOnClickListener { act() }; return c }
        fun rowOf(vararg v: View): LinearLayout { val r = LinearLayout(this); r.setPadding(0, px(4), 0, px(4)); for (x in v) r.addView(x, lay(-2, -2).also { it.rightMargin = px(6) }); return r }
        fun lsl(label: String, mn: Int, mx: Int, v: Int, cb: (Int) -> Unit) {
            val t = tv("$label: $v", 12f); val sk = SeekBar(this); sk.max = mx - mn; sk.progress = (v - mn).coerceIn(0, mx - mn)
            sk.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { t.text = "$label: ${p + mn}"; if (u) cb(p + mn) }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            form.addView(t); form.addView(sk)
        }
        fun pick(onUri: (String) -> Unit) {
            save(); setEdit(false)
            onPicked = { u -> h.post { setEdit(true); if (u.isNotEmpty()) onUri(u); showVtPanel(o, isNew) } }
            startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        val sl = o.getJSONArray("sl")
        for (i in 0 until sl.length()) {
            val s = sl.getJSONObject(i)
            form.addView(tv(if (i == 0) "Diam" else if (i == 1) "Bicara" else "Ekspresi", 12f))
            val nm = EditText(this); nm.setText(s.optString("n", "")); nm.setTextColor(Color.WHITE); nm.textSize = 14f; nm.setSingleLine()
            nm.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(x: Editable?) { s.put("n", x.toString()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
            })
            form.addView(nm)
            val em = EditText(this); em.hint = "Label tombol (emoji/teks, opsional)"; em.setText(s.optString("em", "")); em.setTextColor(Color.WHITE); em.setHintTextColor(0x88FFFFFF.toInt()); em.textSize = 13f; em.setSingleLine()
            em.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(x: Editable?) { s.put("em", x.toString()) }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
            })
            form.addView(em)
            val dots = LinearLayout(this); dots.setPadding(0, px(4), 0, px(4))
            for (c in intArrayOf(gray, accent, Color.parseColor("#DC2626"), Color.parseColor("#16A34A"), Color.parseColor("#CA8A04"), Color.parseColor("#9333EA"))) {
                val dot = View(this); val gd = GradientDrawable(); gd.shape = GradientDrawable.OVAL; gd.setColor(c); gd.setStroke(2, Color.GRAY); dot.background = gd
                dot.setOnClickListener { s.put("bc", c); Toast.makeText(this, "Warna tombol dipilih", Toast.LENGTH_SHORT).show() }
                dots.addView(dot, lay(px(26), px(26)).also { it.rightMargin = px(8) })
            }
            form.addView(dots)
            val parts = mutableListOf<View>(
                chip(if (s.optString("u", "").isEmpty()) "Gambar: kosong" else "Gambar: ganti") { pick { u -> s.put("u", u); reload() } },
                chip(if (s.optString("bu", "").isEmpty()) "Kedip: kosong" else "Kedip: ganti") { pick { u -> s.put("bu", u); reload() } })
            parts.add(chip("Latar: " + mapOf("" to "Asli", "g" to "Hijau", "b" to "Biru", "k" to "Hitam", "w" to "Putih")[s.optString("ck", "")]) {
                val od = listOf("", "g", "b", "k", "w"); s.put("ck", od[(od.indexOf(s.optString("ck", "")) + 1) % od.size]); showVtPanel(o, isNew)
            })
            parts.add(chip("Transisi: " + s.optString("tr", "").ifEmpty { "Global" }) {
                val order = listOf("", "pop", "shake", "jump", "fade", "none")
                s.put("tr", order[(order.indexOf(s.optString("tr", "")) + 1) % order.size]); showVtPanel(o, isNew)
            })
            if (i >= 2) parts.add(chip("Hapus") { val na = JSONArray(); for (k in 0 until sl.length()) if (k != i) na.put(sl.getJSONObject(k)); o.put("sl", na); reload(); showVtPanel(o, isNew) })
            form.addView(rowOf(*parts.toTypedArray()))
            if (s.optString("ck", "").isNotEmpty()) lsl("Kekuatan hapus latar", 5, 100, s.optInt("cs", 50)) { s.put("cs", it) }
            if (i >= 1) {
                form.addView(rowOf(chip(if (s.optBoolean("tk")) "Pemicu mic: Ya" else "Pemicu mic: Tidak") { s.put("tk", !s.optBoolean("tk")); showVtPanel(o, isNew) }))
                if (s.optBoolean("tk")) lsl("Ambang suara", 5, 95, s.optInt("th", 30)) { s.put("th", it) }
            }
        }
        form.addView(rowOf(chip("＋ Tambah ekspresi") { sl.put(JSONObject().put("n", "Ekspresi ${sl.length() + 1}").put("u", "").put("tk", false).put("th", 60)); showVtPanel(o, isNew) }))
        if (items.none { it.optString("vid") == id }) form.addView(rowOf(chip("Tambah panel lagi") { ensureXp(o); showVtPanel(o, isNew) }))
        form.addView(tv("Mode", 14f))
        val man = o.optString("md", "man") == "man"
        form.addView(rowOf(
            chip(if (man) "● Manual" else "○ Manual") { o.put("md", "man"); showVtPanel(o, isNew) },
            chip(if (!man) "● Auto" else "○ Auto") {
                o.put("md", "mic")
                if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) startActivity(Intent(this, PermActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                showVtPanel(o, isNew)
            }))
        form.addView(tv("Kedip", 14f))
        form.addView(rowOf(chip(if (o.optBoolean("bk", true)) "Kedip: Nyala" else "Kedip: Mati") { o.put("bk", !o.optBoolean("bk", true)); showVtPanel(o, isNew) }))
        lsl("Jeda kedip (detik)", 1, 10, o.optInt("bi", 4)) { o.put("bi", it) }
        lsl("Durasi kedip (ms)", 50, 600, o.optInt("bd", 200)) { o.put("bd", it) }
        form.addView(tv("Gerakan", 14f))
        val mo = o.optString("mo", "breath")
        form.addView(rowOf(*listOf("none" to "Diam", "breath" to "Napas", "sway" to "Goyang", "pulse" to "Denyut").map { (k, lb) ->
            chip((if (mo == k) "● " else "○ ") + lb) { o.put("mo", k); showVtPanel(o, isNew) } as View }.toTypedArray()))
        lsl("Kecepatan", 1, 10, o.optInt("mp", 3)) { o.put("mp", it) }
        lsl("Besar gerak (jarak %, derajat, zoom %)", 1, 30, o.optInt("ma", 5)) { o.put("ma", it) }
        form.addView(tv("Transisi saat ganti ekspresi", 14f))
        val trn = o.optString("tr", "pop")
        val hsT = HorizontalScrollView(this)
        hsT.addView(rowOf(*listOf("none" to "Tanpa", "pop" to "Popup", "shake" to "Kedut", "jump" to "Lompat", "fade" to "Pudar").map { (k, lb) ->
            chip((if (trn == k) "● " else "○ ") + lb) { o.put("tr", k); showVtPanel(o, isNew) } as View }.toTypedArray()))
        form.addView(hsT)
        lsl("Besar popup/zoom (%)", 5, 40, o.optInt("ts", 15)) { o.put("ts", it) }
        lsl("Durasi transisi (ms)", 100, 600, o.optInt("td", 250)) { o.put("td", it) }
        lsl("Jeda tahan mulut (ms)", 0, 1000, o.optInt("hl", 250)) { o.put("hl", it) }
        form.addView(tv("Meteran suara (mode Auto)", 12f))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); bar.max = 100; form.addView(bar)
        vtMap[id]?.meter = { l -> bar.progress = l }
        form.addView(rowOf(chip("Kalibrasi (diam 2 detik)") {
            val v = vtMap[id]
            if (v != null) {
                v.calibMax = 0; v.calibEnd = System.currentTimeMillis() + 2000
                h.postDelayed({
                    val th = (v.calibMax + 8).coerceIn(5, 95)
                    for (k in 1 until sl.length()) if (sl.getJSONObject(k).optBoolean("tk")) sl.getJSONObject(k).put("th", th)
                    Toast.makeText(this, "Ambang diatur ke $th", Toast.LENGTH_SHORT).show(); showVtPanel(o, isNew)
                }, 2100)
            }
        }))
        lsl("Kembali ke Diam (detik, 0 = mati)", 0, 10, o.optInt("rt", 3)) { o.put("rt", it) }
        form.addView(rowOf(chip(if (o.optBoolean("fl", false)) "Cermin: Nyala" else "Cermin: Mati") { o.put("fl", !o.optBoolean("fl", false)); showVtPanel(o, isNew) }))
        val ok = Button(this); ok.text = "Selesai"; ok.setOnClickListener { reload(); ensureXp(o); back() }
        val sc = ScrollView(this); sc.addView(form); box.addView(sc, lay(-1, 0, 1f)); box.addView(ok)
        place(box, true, true)
    }
    private fun locked(id: String) = items.firstOrNull { it.getString("id") == id }?.optBoolean("lk", false) ?: false
    private fun setLock(o: JSONObject, v: Boolean) {
        o.put("lk", v); save()
        val id = o.getString("id"); val p = params[id] ?: return; val vw = views[id] ?: return
        p.flags = if (touchFor(id, edit)) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(vw, p)
        val c = ctlOf(id)
        if (c != null) for (i in intArrayOf(1, 3, 4)) c.getChildAt(i).visibility = if (edit && !v) View.VISIBLE else View.GONE
        hl(id, false)
        refreshLocks()
    }
    private fun boxOf(id: String) = views[id]?.getChildAt(0) as? FrameLayout
    private fun contentOf(id: String) = boxOf(id)?.getChildAt(0)
    private fun ctlOf(id: String) = boxOf(id)?.getChildAt(1) as? FrameLayout
    private fun ctlMode(m: Int) {
        for (id in views.keys) {
            val c = ctlOf(id) ?: continue
            c.visibility = if (m == 0) View.GONE else View.VISIBLE
            for (i in intArrayOf(1, 3, 4)) c.getChildAt(i).visibility = if (m == 2 && !locked(id)) View.VISIBLE else View.GONE
        }
    }
    private fun relayout(o: JSONObject) {
        val id = o.getString("id"); val p = params[id] ?: return; val v = views[id] ?: return
        val w = o.getInt("w"); val hh = o.getInt("h")
        val th = Math.toRadians(o.optInt("r", 0).toDouble()); val c = abs(Math.cos(th)); val sn = abs(Math.sin(th))
        val bw = (w * c + hh * sn).toInt(); val bh = (w * sn + hh * c).toInt()
        p.width = bw; p.height = bh; p.x = posX(o) - (bw - w) / 2; p.y = posY(o) - (bh - hh) / 2
        val box = v.getChildAt(0) as FrameLayout
        val l = box.layoutParams as FrameLayout.LayoutParams; l.width = w; l.height = hh; l.gravity = Gravity.CENTER
        box.layoutParams = l; box.rotation = o.optInt("r", 0).toFloat()
        wm.updateViewLayout(v, p)
    }

    private fun addWidget(o: JSONObject) {
        val id = o.getString("id")
        val root = FrameLayout(this); val box = FrameLayout(this)
        box.setBackgroundColor(Color.argb(o.optInt("bg", 0) * 255 / 100, 0, 0, 0))
        val content: View
        var clp = FrameLayout.LayoutParams(-1, -1)
        when (o.getString("t")) {
            "web" -> {
                val w = WebView(this); w.setBackgroundColor(0); w.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true; w.settings.mediaPlaybackRequiresUserGesture = false
                CookieManager.getInstance().setAcceptCookie(true); CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView?, u: String?) {
                        val sd = o.optInt("sh", 0)
                        if (sd > 0) v?.evaluateJavascript("document.documentElement.style.filter='drop-shadow(0 0 ${sd}px black)'", null)
                    }
                }
                w.loadUrl(o.getString("u")); content = w
            }
            "vt" -> content = makeVt(o, id)
            "xp" -> content = makeXp(o, id)
            "txt" -> {
                val t = TextView(this); t.text = o.getString("u"); t.setTextColor(o.optInt("c", Color.WHITE))
                val sd = o.optInt("sh", 4); if (sd > 0) t.setShadowLayer(sd.toFloat(), 0f, 0f, Color.BLACK)
                t.typeface = Typeface.create(o.optString("f", "sans-serif"), (if (o.optBoolean("b", false)) 1 else 0) or (if (o.optBoolean("i", false)) 2 else 0))
                val st = o.optString("s", "none")
                if (st == "run") {
                    t.setSingleLine(); t.setTextSize(TypedValue.COMPLEX_UNIT_PX, o.getInt("h") * 0.5f); t.gravity = Gravity.CENTER_VERTICAL
                    clp = FrameLayout.LayoutParams(-2, -1)
                    t.post {
                        val bw = o.getInt("w").toFloat(); val tw = t.width.toFloat()
                        val a = ValueAnimator.ofFloat(bw, -tw); a.duration = ((bw + tw) / d * 14).toLong().coerceAtLeast(2000)
                        a.interpolator = LinearInterpolator(); a.repeatCount = ValueAnimator.INFINITE
                        a.addUpdateListener { t.translationX = it.animatedValue as Float }; a.start(); anims[id] = a
                    }
                } else {
                    t.gravity = Gravity.CENTER; t.setAutoSizeTextTypeUniformWithConfiguration(10, 200, 2, TypedValue.COMPLEX_UNIT_SP)
                    if (st == "blink") { val a = ObjectAnimator.ofFloat(t, "alpha", 1f, 0.15f); a.duration = 600; a.repeatCount = ValueAnimator.INFINITE; a.repeatMode = ValueAnimator.REVERSE; a.start(); anims[id] = a }
                    if (st == "pulse") {
                        val a = ObjectAnimator.ofPropertyValuesHolder(t, PropertyValuesHolder.ofFloat("scaleX", 1f, 1.15f), PropertyValuesHolder.ofFloat("scaleY", 1f, 1.15f))
                        a.duration = 700; a.repeatCount = ValueAnimator.INFINITE; a.repeatMode = ValueAnimator.REVERSE; a.start(); anims[id] = a
                    }
                }
                content = t
            }
            else -> {
                val uri = Uri.parse(o.getString("u"))
                val mime = try { contentResolver.getType(uri) ?: "" } catch (e: Exception) { "" }
                if (mime.startsWith("video/")) content = videoView(o)
                else {
                    val iv = ImageView(this); iv.scaleType = ImageView.ScaleType.FIT_CENTER; var ok = false
                    if (Build.VERSION.SDK_INT >= 28 && (mime == "image/gif" || mime == "image/webp")) {
                        try {
                            val dr = ImageDecoder.decodeDrawable(ImageDecoder.createSource(contentResolver, uri)); iv.setImageDrawable(dr)
                            if (dr is AnimatedImageDrawable) { dr.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; dr.start() }
                            ok = true
                        } catch (e: Exception) {}
                    }
                    if (!ok && o.optInt("sh", 0) > 0) { try { iv.setImageBitmap(shadowed(loadBmp(uri), o.getInt("sh"))); ok = true } catch (e: Exception) {} }
                    if (!ok) iv.setImageURI(uri)
                    content = iv
                }
            }
        }
        if (o.getString("t") != "txt" || o.optString("s", "none") == "none") content.alpha = o.getInt("a") / 100f
        content.visibility = if (o.optBoolean("v", true)) View.VISIBLE else View.INVISIBLE
        box.addView(content, clp)

        val ctl = FrameLayout(this); ctl.visibility = if (edit) View.VISIBLE else View.GONE
        val border = View(this)
        val g = GradientDrawable(); g.setColor(0x14FFFFFF); g.setStroke(3, if (o.optBoolean("lk", false)) 0x55FFFFFF else Color.WHITE); border.background = g
        borders[id] = g; ctl.addView(border)
        val shield = View(this); ctl.addView(shield)
        val label = tv("", 13f); label.setBackgroundColor(0xAA000000.toInt()); label.visibility = View.GONE
        ctl.addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        val sz = px(34)
        val gear = cb("gear", gray); gear.setOnClickListener { showSettings(o, false) }
        val del = cb("close", Color.parseColor("#DC2626")); del.setOnClickListener { confirmDelete(o) }
        ctl.addView(gear, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.START))
        ctl.addView(del, FrameLayout.LayoutParams(sz, sz, Gravity.TOP or Gravity.END))
        if (o.optBoolean("lk", false)) { shield.visibility = View.GONE; gear.visibility = View.GONE; del.visibility = View.GONE }
        box.addView(ctl)
        root.addView(box, FrameLayout.LayoutParams(o.getInt("w"), o.getInt("h"), Gravity.CENTER))
        val p = lp(10, 10, if (o.getString("t") == "xp" || o.optBoolean("ia", false)) !(edit && o.optBoolean("lk", false)) else edit && !o.optBoolean("lk", false)); p.alpha = if (edit || peek) 1f else galpha / 100f
        if (o.optBoolean("ia", false)) p.flags = p.flags and LP.FLAG_NOT_FOCUSABLE.inv()
        wm.addView(root, p); views[id] = root; params[id] = p; relayout(o); bringBubble(); if (edit) refreshLocks()

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var rs = false; var mv = false
        val rrun = Runnable { rs = true; hl(id, true); label.visibility = View.VISIBLE; Toast.makeText(this, "Resize widget", Toast.LENGTH_SHORT).show() }
        shield.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; rs = false; mv = false
                    val m = px(30)
                    if (e.x < m || e.y < m || e.x > o.getInt("w") - m || e.y > o.getInt("h") - m) h.postDelayed(rrun, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - sx) > 12 || abs(e.rawY - sy) > 12) { mv = true; if (!rs) h.removeCallbacks(rrun) }
                    if (rs) {
                        o.put("w", (e.rawX - posX(o)).toInt().coerceAtLeast(60)); o.put("h", (e.rawY - posY(o)).toInt().coerceAtLeast(60))
                        label.text = "W: ${o.getInt("w")}  H: ${o.getInt("h")}"; relayout(o)
                    } else if (mv) {
                        var nx = ox + (e.rawX - sx).toInt(); var ny = oy + (e.rawY - sy).toInt()
                        val s1 = abs(nx + p.width / 2 - sw / 2) < 15; val s2 = abs(ny + p.height / 2 - sh / 2) < 15
                        if (s1) nx = sw / 2 - p.width / 2
                        if (s2) ny = sh / 2 - p.height / 2
                        guides(s1, s2); p.x = nx; p.y = ny; wm.updateViewLayout(root, p)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(rrun); guides(false, false)
                    if (rs) { hl(id, false); label.visibility = View.GONE }
                    else if (mv) o.put(kx(), p.x + (p.width - o.getInt("w")) / 2).put(ky(), p.y + (p.height - o.getInt("h")) / 2)
                    save()
                }
            }
            true
        }
    }
    private fun killView(id: String) {
        val v = views.remove(id) ?: return
        params.remove(id); borders.remove(id); anims.remove(id)?.cancel(); vtMap.remove(id)?.stop(); xpRoot.remove(id); wm.removeView(v)
        ((v.getChildAt(0) as FrameLayout).getChildAt(0) as? WebView)?.destroy()
    }
    private fun setEdit(on: Boolean) {
        edit = on; if (on) { peek = false; hideArrow(); hideExpr() }
        bubble?.alpha = if (on) 1f else 0.35f
        ctlMode(if (on) 2 else 0)
        for ((id, v) in views) {
            val p = params[id]!!
            p.flags = if (touchFor(id, on)) p.flags and LP.FLAG_NOT_TOUCHABLE.inv() else p.flags or LP.FLAG_NOT_TOUCHABLE
            p.alpha = if (on) 1f else galpha / 100f
            wm.updateViewLayout(v, p)
        }
        if (on) showDock() else { closeSheet(); closeDock() }
        refreshLocks()
    }
    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        h.postDelayed({
            for (o in items) relayout(o)
            refreshLocks()
            snapBubble()
            if (peek) showArrow()
            if (sheet != null) back() else if (dock != null) showDock()
        }, 200)
    }
    private fun confirmClose() {
        closeDock()
        val box = card()
        val t = tv("Kamu yakin ingin menutup overlay app?", 15f); t.setPadding(0, 0, 0, px(12))
        val row = LinearLayout(this)
        val no = Button(this); no.text = "Batal"; no.setOnClickListener { back() }
        val yes = Button(this); yes.text = "Tutup"; yes.setOnClickListener { shutdown() }
        row.addView(no, lay(0, -2, 1f)); row.addView(yes, lay(0, -2, 1f))
        box.addView(t); box.addView(row); place(box, false, false)
    }

    // ---------- dock & sheets ----------
    private fun showDock() {
        closeDock()
        val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(px(6), px(6), px(6), px(6))
        r.background = rr(Color.WHITE, px(40).toFloat())
        val add = LinearLayout(this); add.gravity = Gravity.CENTER_VERTICAL; add.setPadding(px(14), px(9), px(18), px(9))
        add.background = rr(ink, px(30).toFloat()); add.setOnClickListener { showAdd() }
        add.addView(cb("plus", ink, Color.WHITE, 2), lay(px(22), px(22))); val t = tv("Add Widget", 14f); t.setPadding(px(8), 0, 0, 0); add.addView(t)
        val ly = cb("layers", Color.parseColor("#E5E7EB"), ink, 10); ly.setOnClickListener { showLayers() }
        val x = cb("close", Color.parseColor("#E5E7EB"), ink, 10); x.setOnClickListener { confirmClose() }
        r.addView(add); r.addView(ly, lay(px(40), px(40)).also { it.leftMargin = px(6) }); r.addView(x, lay(px(40), px(40)).also { it.leftMargin = px(6) })
        val p = lp(-2, -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(20) + navB()
        wm.addView(r, p); dock = r
        r.translationY = px(70).toFloat(); r.alpha = 0f; r.animate().translationY(0f).alpha(1f).setDuration(220).start()
        showDockSlider()
    }
    private fun setAlphaAll(a: Float) { for ((id, v) in views) { params[id]?.let { it.alpha = a; wm.updateViewLayout(v, it) } } }
    private fun showDockSlider() {
        val box = card(); box.setPadding(px(14), px(8), px(14), px(8))
        val t = tv("Transparansi keseluruhan: $galpha%", 12f)
        val sk = SeekBar(this); sk.max = 80; sk.progress = galpha - 20
        sk.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { t.text = "Transparansi keseluruhan: ${p + 20}%"; setAlphaAll((p + 20) / 100f) } }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { galpha = sk.progress + 20; getSharedPreferences("p", 0).edit().putInt("galpha2", galpha).apply(); setAlphaAll(1f) }
        })
        box.addView(t); box.addView(sk)
        val p = lp(px(280), -2, true); p.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; p.y = px(84) + navB()
        wm.addView(box, p); dock2 = box
    }
    private fun newItem(t: String, u: String): JSONObject {
        val w = if (t == "web") 450 else 400; val hh = when (t) { "web" -> 338; "txt" -> 120; else -> 300 }
        val a = minOf(sw, sh); val b = maxOf(sw, sh)
        return JSONObject().put("id", System.currentTimeMillis().toString()).put("t", t)
            .put("n", typeName(JSONObject().put("t", t)).replaceFirstChar { it.uppercase() }).put("u", u)
            .put("w", w).put("h", hh).put("a", 100).put("r", 0).put("v", true)
            .put("x0", (a - w) / 2).put("y0", (b - hh) / 2).put("x1", (b - w) / 2).put("y1", (a - hh) / 2)
    }
    private fun showAdd() {
        closeDock()
        val box = card(); box.addView(header("Add Widget"))
        val row = LinearLayout(this); row.gravity = Gravity.CENTER; row.setPadding(0, px(16), 0, px(4))
        fun opt(label: String, icon: String, act: () -> Unit) {
            val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER; c.setPadding(px(6), 0, px(6), 0)
            c.addView(cb(icon, gray, Color.WHITE, 16), lay(px(58), px(58))); val t = tv(label, 12f); t.gravity = Gravity.CENTER; t.setPadding(0, px(6), 0, 0); c.addView(t)
            c.setOnClickListener { act() }; row.addView(c)
        }
        opt("Media", "image") {
            setEdit(false)
            onPicked = { u -> h.post { setEdit(true); if (u.isNotEmpty()) showSettings(newItem("pic", u), true) } }
            startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        opt("PNGTuber", "user") { showVtPanel(newVt(), true) }
        opt("Web Source", "globe") { showSettings(newItem("web", ""), true) }
        opt("Song Share", "globe") { val o = newItem("web", ""); o.put("n", "Song Share").put("w", 240).put("h", 240); showSettings(o, true) }
        opt("Text", "text") { showSettings(newItem("txt", "Teks kamu"), true) }
        val hs = HorizontalScrollView(this); hs.addView(row); box.addView(hs); place(box, false, false)
    }
    private fun restack() { for (o in items) { val id = o.getString("id"); val v = views[id] ?: continue; wm.removeView(v); wm.addView(v, params[id]) }; bringBubble() }

    private fun showLayers() {
        closeDock()
        val box = card(); box.addView(header("Layers"))
        val list = LinearLayout(this); list.orientation = LinearLayout.VERTICAL
        fun build() {
            list.removeAllViews()
            if (items.isEmpty()) list.addView(tv("Belum ada widget"))
            for (o in items.reversed()) {
                val id = o.getString("id")
                val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL; r.setPadding(0, px(5), 0, px(5)); r.tag = o
                val n = tv(o.getString("n") + "  · " + typeName(o)); n.setPadding(px(4), px(8), px(4), px(8))
                n.setOnClickListener { items.forEach { hl(it.getString("id"), false) }; hl(id, true) }
                val s = Switch(this); s.isChecked = o.optBoolean("v", true)
                s.setOnCheckedChangeListener { _, c -> o.put("v", c); contentOf(id)?.visibility = if (c) View.VISIBLE else View.INVISIBLE; save() }
                val gr = cb("gear", gray); gr.setOnClickListener { showSettings(o, false) }
                val lk = cb(if (o.optBoolean("lk", false)) "lock" else "unlock", if (o.optBoolean("lk", false)) accent else gray)
                lk.setOnClickListener { setLock(o, !o.optBoolean("lk", false)); build() }
                val grip = cb("grip", gray); var sy = 0f
                grip.setOnTouchListener { v, e ->
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sy = e.rawY; v.parent.requestDisallowInterceptTouchEvent(true) }
                        MotionEvent.ACTION_MOVE -> r.translationY = e.rawY - sy
                        MotionEvent.ACTION_UP -> {
                            val i = list.indexOfChild(r); val ni = (i + Math.round((e.rawY - sy) / r.height)).coerceIn(0, list.childCount - 1)
                            val order = (0 until list.childCount).map { list.getChildAt(it).tag as JSONObject }.toMutableList()
                            order.removeAt(i); order.add(ni, o)
                            items.clear(); items.addAll(order.reversed()); restack(); save(); build()
                        }
                    }
                    true
                }
                r.addView(n, lay(0, -2, 1f)); r.addView(s); r.addView(lk, lay(px(34), px(34)).also { it.leftMargin = px(8) }); r.addView(gr, lay(px(34), px(34)).also { it.leftMargin = px(8) }); r.addView(grip, lay(px(34), px(34)).also { it.leftMargin = px(6) })
                list.addView(r)
            }
        }
        build()
        val bar = LinearLayout(this); bar.setPadding(0, px(8), 0, px(4))
        for ((lb, v) in listOf("Kunci semua" to true, "Buka semua" to false)) {
            val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
            chip.setOnClickListener { items.forEach { setLock(it, v) }; build() }
            bar.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
        }
        box.addView(bar)
        val sc = ScrollView(this); sc.addView(list); box.addView(sc); place(box, false, true)
    }
    private fun confirmDelete(o: JSONObject) {
        closeDock()
        val box = card()
        val extra = if (o.getString("t") == "web") " - " + o.getString("u").take(30) else ""
        val t = tv("Kamu ingin menghapus widget ${typeName(o)} - ${o.getString("n")}$extra ?", 15f); t.maxWidth = px(300); t.setPadding(0, 0, 0, px(12))
        val row = LinearLayout(this)
        val no = Button(this); no.text = "Batal"; no.setOnClickListener { back() }
        val yes = Button(this); yes.text = "Hapus"; yes.setOnClickListener { killView(o.getString("id")); items.remove(o); save(); back() }
        row.addView(no, lay(0, -2, 1f)); row.addView(yes, lay(0, -2, 1f))
        box.addView(t); box.addView(row); place(box, false, false)
    }

    private fun showSettings(o: JSONObject, isNew: Boolean) {
        closeDock()
        val id = o.getString("id"); val t = o.getString("t")
        val snap = JSONObject(o.toString())
        if (isNew) { items.add(o); addWidget(o) }
        var liveCb: () -> Unit = {}
        fun rebuild() { killView(id); addWidget(o); restack() }
        fun et(v: String, text: Boolean = false): EditText {
            val e = EditText(this); e.setText(v); e.setTextColor(Color.WHITE); e.setHintTextColor(0x88FFFFFF.toInt()); e.textSize = 14f
            e.inputType = if (text) InputType.TYPE_CLASS_TEXT else (InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED)
            e.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE; e.setSingleLine()
            e.setOnEditorActionListener { v, _, _ ->
                (getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(v.windowToken, 0); v.clearFocus(); true
            }
            return e
        }
        val form = LinearLayout(this); form.orientation = LinearLayout.VERTICAL
        fun sl(label: String, mn: Int, mx: Int, v: Int): EditText {
            val e = et(v.toString()); val s = SeekBar(this); s.max = mx - mn; s.progress = (v - mn).coerceIn(0, mx - mn)
            var lock = false
            s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { if (u) { lock = true; e.setText((p + mn).toString()); lock = false; liveCb() } }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
            e.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(x: Editable?) { if (!lock) { e.text.toString().toIntOrNull()?.let { s.progress = (it - mn).coerceIn(0, mx - mn) }; liveCb() } }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, dd: Int) {}
            })
            val r = LinearLayout(this); r.gravity = Gravity.CENTER_VERTICAL
            r.addView(tv(label, 13f), lay(px(70), -2)); r.addView(s, lay(0, -2, 1f)); r.addView(e, lay(px(70), -2))
            form.addView(r); return e
        }
        val name = et(o.getString("n"), true); val url = et(o.getString("u"), true); url.hint = "https://..."
        form.addView(tv("Nama", 12f)); form.addView(name)
        val lkChip = tv(if (o.optBoolean("lk", false)) "Terkunci (ketuk untuk buka)" else "Kunci widget", 13f)
        lkChip.setPadding(px(12), px(7), px(12), px(7)); lkChip.background = rr(gray, px(14).toFloat())
        lkChip.setOnClickListener { val nv = !o.optBoolean("lk", false); setLock(o, nv); lkChip.text = if (nv) "Terkunci (ketuk untuk buka)" else "Kunci widget" }
        form.addView(lkChip, lay(-2, -2).also { it.topMargin = px(8) })
        if (t == "web") {
            val ia = tv(if (o.optBoolean("ia", false)) "Interaktif: Nyala (bisa disentuh)" else "Interaktif: Mati", 13f)
            ia.setPadding(px(12), px(7), px(12), px(7)); ia.background = rr(if (o.optBoolean("ia", false)) accent else gray, px(14).toFloat())
            ia.setOnClickListener { o.put("ia", !o.optBoolean("ia", false)); save(); rebuild(); showSettings(o, false) }
            form.addView(ia, lay(-2, -2).also { it.topMargin = px(8) })
        }
        if (t == "xp") {
            val c = tv("Kolom: " + (if (o.optInt("cols", 0) == 0) "Otomatis" else o.optInt("cols").toString()), 13f)
            c.setPadding(px(12), px(7), px(12), px(7)); c.background = rr(gray, px(14).toFloat())
            c.setOnClickListener { o.put("cols", (o.optInt("cols", 0) + 1) % 5); save(); refreshXp(); c.text = "Kolom: " + (if (o.optInt("cols", 0) == 0) "Otomatis" else o.optInt("cols").toString()) }
            form.addView(c, lay(-2, -2).also { it.topMargin = px(8) })
        }
        if (t == "vt") {
            val ek = tv("Edit karakter", 13f); ek.setPadding(px(12), px(7), px(12), px(7)); ek.background = rr(accent, px(14).toFloat())
            ek.setOnClickListener { showVtPanel(o, false) }
            form.addView(ek, lay(-2, -2).also { it.topMargin = px(8) })
        }
        if (t == "pic" && !isNew) {
            val rp = tv("Ganti file", 13f); rp.setPadding(px(12), px(7), px(12), px(7)); rp.background = rr(accent, px(14).toFloat())
            rp.setOnClickListener {
                save(); setEdit(false)
                onPicked = { u -> h.post { setEdit(true); if (u.isNotEmpty()) { o.put("u", u); killView(id); addWidget(o); restack(); save() }; showSettings(o, false) } }
                startActivity(Intent(this, PickActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            form.addView(rp, lay(-2, -2).also { it.topMargin = px(8) })
        }
        if (t == "web" || t == "txt") { form.addView(tv(if (t == "web") "Link URL" else "Teks", 12f)); form.addView(url) }
        if (t == "txt") {
            form.addView(tv("Warna", 14f))
            val cr = LinearLayout(this); cr.setPadding(0, px(4), 0, px(4))
            for (c in intArrayOf(Color.WHITE, Color.parseColor("#FACC15"), Color.parseColor("#EF4444"), Color.parseColor("#22C55E"), Color.parseColor("#22D3EE"), Color.parseColor("#3B82F6"), Color.parseColor("#EC4899"), Color.BLACK)) {
                val dot = View(this); val g = GradientDrawable(); g.shape = GradientDrawable.OVAL; g.setColor(c); g.setStroke(2, Color.GRAY); dot.background = g
                dot.setOnClickListener { o.put("c", c); rebuild() }
                cr.addView(dot, lay(px(30), px(30)).also { it.rightMargin = px(8) })
            }
            form.addView(cr)
            form.addView(tv("Efek", 14f))
            val sr = LinearLayout(this)
            for ((lb, key) in listOf("Tetap" to "none", "Jalan" to "run", "Kedip" to "blink", "Denyut" to "pulse")) {
                val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
                chip.setOnClickListener { o.put("s", key); rebuild() }
                sr.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
            }
            form.addView(sr)
            form.addView(tv("Font", 14f))
            val hs = HorizontalScrollView(this); val fr2 = LinearLayout(this); hs.addView(fr2)
            for ((lb, fam) in listOf("Sans" to "sans-serif", "Serif" to "serif", "Mono" to "monospace", "Tulis" to "cursive", "Lucu" to "casual", "Ramping" to "sans-serif-condensed", "Tebal" to "sans-serif-black")) {
                val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
                chip.setOnClickListener { o.put("f", fam); rebuild() }
                fr2.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
            }
            form.addView(hs)
            val bi = LinearLayout(this); bi.setPadding(0, px(6), 0, 0)
            for ((lb, key) in listOf("B  Bold" to "b", "I  Italic" to "i")) {
                val chip = tv(lb, 13f); chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
                chip.setOnClickListener { o.put(key, !o.optBoolean(key, false)); rebuild() }
                bi.addView(chip, lay(-2, -2).also { it.rightMargin = px(6) })
            }
            form.addView(bi)
        }
        if (t == "pic" && (try { contentResolver.getType(Uri.parse(o.getString("u"))) ?: "" } catch (e: Exception) { "" }).startsWith("video/")) {
            val chip = tv(if (o.optBoolean("snd", false)) "Suara video: Nyala" else "Suara video: Mati", 13f)
            chip.setPadding(px(12), px(7), px(12), px(7)); chip.background = rr(gray, px(14).toFloat())
            chip.setOnClickListener { o.put("snd", !o.optBoolean("snd", false)); rebuild(); chip.text = if (o.optBoolean("snd", false)) "Suara video: Nyala" else "Suara video: Mati" }
            form.addView(chip, lay(-2, -2).also { it.topMargin = px(8) })
        }
        val big = maxOf(sw, sh)
        form.addView(tv("Position", 14f))
        val fx = sl("X", -sw, big, posX(o)); val fy = sl("Y", -sh, big, posY(o))
        form.addView(tv("Scale", 14f))
        val fw = sl("W", 60, big, o.getInt("w")); val fh = sl("H", 60, big, o.getInt("h"))
        form.addView(tv("Rotate", 14f))
        val fr = sl("°", -180, 180, o.optInt("r", 0))
        form.addView(tv("Alignment", 14f))
        val icons = arrayOf("↖", "↑", "↗", "←", "●", "→", "↙", "↓", "↘")
        for (ay in 0..2) {
            val r = LinearLayout(this); r.gravity = Gravity.CENTER
            for (ax in 0..2) {
                val b = tv(icons[ay * 3 + ax], 16f); b.gravity = Gravity.CENTER; b.background = rr(gray, px(12).toFloat())
                b.setOnClickListener {
                    val w = fw.text.toString().toIntOrNull() ?: 100; val hh = fh.text.toString().toIntOrNull() ?: 100
                    fx.setText(((sw - w) * ax / 2).toString()); fy.setText(((sh - hh) * ay / 2).toString())
                }
                r.addView(b, lay(px(44), px(40)).also { it.setMargins(px(4), px(3), px(4), px(3)) })
            }
            form.addView(r)
        }
        form.addView(tv("Transparansi (kanan = jelas)", 12f))
        val seek = SeekBar(this); seek.max = 100; seek.progress = o.getInt("a"); form.addView(seek)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { o.put("a", p.coerceAtLeast(10)); contentOf(id)?.alpha = p.coerceAtLeast(10) / 100f }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        form.addView(tv("Bayangan mengikuti bentuk (0 = mati)", 12f))
        val shS = SeekBar(this); shS.max = 20; shS.progress = o.optInt("sh", if (t == "txt") 4 else 0); form.addView(shS)
        shS.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {}
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { o.put("sh", shS.progress); rebuild() }
        })
        form.addView(tv("Latar gelap (0 = bening total)", 12f))
        val bgS = SeekBar(this); bgS.max = 80; bgS.progress = o.optInt("bg", 0); form.addView(bgS)
        bgS.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { o.put("bg", p); boxOf(id)?.setBackgroundColor(Color.argb(p * 255 / 100, 0, 0, 0)) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        liveCb = {
            o.put(kx(), fx.text.toString().toIntOrNull() ?: posX(o)).put(ky(), fy.text.toString().toIntOrNull() ?: posY(o))
            o.put("w", (fw.text.toString().toIntOrNull() ?: 60).coerceAtLeast(60)).put("h", (fh.text.toString().toIntOrNull() ?: 60).coerceAtLeast(60))
            o.put("r", fr.text.toString().toIntOrNull() ?: 0); relayout(o)
        }
        val btns = LinearLayout(this)
        val cancel = Button(this); cancel.text = "Batal"
        cancel.setOnClickListener {
            if (isNew) { killView(id); items.remove(o) } else { for (k in snap.keys()) o.put(k, snap.get(k)); rebuild() }
            back()
        }
        val ok = Button(this); ok.text = "OK"
        ok.setOnClickListener {
            var u = url.text.toString().trim()
            if (t == "web" || t == "txt") {
                if (u.isEmpty()) { Toast.makeText(this, "Isi dulu", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (t == "web" && !u.startsWith("http")) u = "https://$u"
                o.put("u", u)
            }
            o.put("n", name.text.toString()); liveCb(); rebuild(); back()
        }
        btns.addView(cancel, lay(0, -2, 1f)); btns.addView(ok, lay(0, -2, 1f))
        val box = card(); box.addView(header("Widget Settings"))
        val sc = ScrollView(this); sc.addView(form); box.addView(sc, lay(-1, 0, 1f)); box.addView(btns)
        place(box, true, true)
    }

    override fun onDestroy() { shutdown(false); instance = null; super.onDestroy() }
}
