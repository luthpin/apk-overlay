package com.example.overlaystudio

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import android.widget.Toast

class MainActivity : Activity() {
    override fun onResume() {
        super.onResume()
        val s = OverlayService.instance
        if (s == null) {
            Toast.makeText(this, "Aktifkan 'Streamix' di Aksesibilitas, lalu buka aplikasi lagi", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else { s.start(); finish() }
    }
}
