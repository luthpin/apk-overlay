package com.example.overlaystudio

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(48, 120, 48, 48)
        fun add(t: String, a: () -> Unit) {
            val bt = Button(this); bt.text = t; bt.setOnClickListener { a() }; l.addView(bt)
        }
        add("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        add("2. Mulai overlay") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan dulu (langkah 1)", Toast.LENGTH_SHORT).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
                startForegroundService(Intent(this, OverlayService::class.java))
            }
        }
        add("Hentikan overlay") { stopService(Intent(this, OverlayService::class.java)) }
        setContentView(l)
    }
}
