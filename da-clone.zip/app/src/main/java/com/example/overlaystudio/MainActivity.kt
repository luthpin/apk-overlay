package com.example.overlaystudio

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var p: SharedPreferences
    private val accent = Color.parseColor("#5B6CFF")
    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rr(c: Int, r: Int): GradientDrawable { val g = GradientDrawable(); g.setColor(c); g.cornerRadius = px(r).toFloat(); return g }
    private fun tv(s: String, sz: Float = 14f, c: Int = Color.WHITE): TextView { val t = TextView(this); t.text = s; t.textSize = sz; t.setTextColor(c); return t }
    private fun card(): LinearLayout {
        val l = LinearLayout(this); l.orientation = LinearLayout.VERTICAL; l.setPadding(px(16), px(14), px(16), px(14)); l.background = rr(Color.parseColor("#171A26"), 18)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, px(10), 0, 0); l.layoutParams = lp; return l
    }
    private fun chip(lb: String, on: Boolean, act: () -> Unit): TextView {
        val c = tv(lb, 13f); c.setPadding(px(14), px(8), px(14), px(8)); c.background = rr(if (on) accent else Color.parseColor("#2A2F42"), 14)
        c.setOnClickListener { act() }; return c
    }
    private fun row(vararg v: View): LinearLayout { val r = LinearLayout(this); r.setPadding(0, px(6), 0, px(2)); for (x in v) { val lp = LinearLayout.LayoutParams(-2, -2); lp.rightMargin = px(8); r.addView(x, lp) }; return r }
    private fun btn(lb: String, c: Int, act: () -> Unit): Button {
        val b = Button(this); b.text = lb; b.setTextColor(Color.WHITE); b.isAllCaps = false; b.background = rr(c, 14); b.setOnClickListener { act() }; return b
    }
    private fun slider(label: String, mn: Int, mx: Int, key: String, def: Int, unit: String, root: LinearLayout) {
        val v = p.getInt(key, def); val t = tv("$label: $v$unit", 13f); val s = SeekBar(this); s.max = mx - mn; s.progress = v - mn
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, pr: Int, u: Boolean) { t.text = "$label: ${pr + mn}$unit"; if (u) p.edit().putInt(key, pr + mn).apply() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        root.addView(t); root.addView(s)
    }

    override fun onCreate(b: Bundle?) { super.onCreate(b); p = getSharedPreferences("rec", 0); build() }
    override fun onResume() { super.onResume(); build() }

    private fun build() {
        val root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL; root.setPadding(px(16), px(40), px(16), px(24))
        root.addView(tv("Streamix", 26f))
        root.addView(tv("Pilih mode", 13f, Color.GRAY))

        val a = card(); a.addView(tv("Mode A · Overlay layar", 16f)); a.addView(tv("Widget overlay di atas aplikasi lain (goal, alert, PNGTuber, Song Share).", 12f, Color.GRAY))
        val on = OverlayService.instance != null
        a.addView(btn(if (on) "Tampilkan overlay" else "Aktifkan layanan overlay", accent) {
            val s = OverlayService.instance
            if (s == null) { Toast.makeText(this, "Nyalakan 'Streamix' di Aksesibilitas, lalu buka lagi", Toast.LENGTH_LONG).show(); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            else { s.start(); finish() }
        })
        root.addView(a)

        val bc = card(); bc.addView(tv("Mode B · Encoder RTMP (stream key)", 16f)); bc.addView(tv("Segera hadir (Fase 2).", 12f, Color.GRAY)); root.addView(bc)

        val c = card(); c.addView(tv("Mode C · Rekam layar", 16f)); c.addView(tv("Rekam layar, suara game, dan mic ke MP4 di Movies/Streamix. Cocok untuk menguji hasil.", 12f, Color.GRAY))
        val res = p.getInt("res", 720); val fps = p.getInt("fps", 30)
        c.addView(tv("Resolusi", 13f)); c.addView(row(*listOf(480, 720, 1080).map { r -> chip("${r}p", res == r) { p.edit().putInt("res", r).apply(); build() } as View }.toTypedArray()))
        c.addView(tv("FPS", 13f)); c.addView(row(*listOf(30, 60).map { f -> chip("$f", fps == f) { p.edit().putInt("fps", f).apply(); build() } as View }.toTypedArray()))
        slider("Bitrate", 1000, 9000, "br", 2500, " kbps", c)
        slider("Volume mic", 0, 100, "mg", 100, "%", c)
        slider("Volume suara game", 0, 100, "gg", 100, "%", c)
        c.addView(tv("Orientasi mengikuti layar saat tombol rekam ditekan. Pakai earphone supaya suara game tidak mantul ke mic.", 11f, Color.GRAY))
        if (RecordService.running) c.addView(btn("Stop rekam", Color.parseColor("#DC2626")) { startService(Intent(this, RecordService::class.java).setAction("stop")); build() })
        else c.addView(btn("Mulai rekam", Color.parseColor("#EF4444")) { startRec() })
        if (RecordService.lastFile.isNotEmpty()) c.addView(tv("Terakhir: " + RecordService.lastFile, 11f, Color.parseColor("#7DD3A0")))
        root.addView(c)

        val sc = ScrollView(this); sc.setBackgroundColor(Color.parseColor("#0E1019")); sc.addView(root); setContentView(sc)
    }

    private fun startRec() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(android.Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) need.add("android.permission.POST_NOTIFICATIONS")
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 7); return }
        startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 8)
    }
    override fun onRequestPermissionsResult(c: Int, ps: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, ps, r)
        if (c == 7) { if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec() else Toast.makeText(this, "Izin mikrofon diperlukan untuk suara", Toast.LENGTH_LONG).show() }
    }
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq == 8 && rs == RESULT_OK && d != null) {
            val m = DisplayMetrics(); @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealMetrics(m)
            val sd = p.getInt("res", 720); val portrait = m.heightPixels >= m.widthPixels
            val lg = ((sd * maxOf(m.widthPixels, m.heightPixels).toFloat() / minOf(m.widthPixels, m.heightPixels)).toInt() / 2) * 2
            val i = Intent(this, RecordService::class.java).putExtra("code", rs).putExtra("data", d)
                .putExtra("w", if (portrait) sd else lg).putExtra("h", if (portrait) lg else sd).putExtra("dpi", m.densityDpi)
                .putExtra("fps", p.getInt("fps", 30)).putExtra("br", p.getInt("br", 2500))
                .putExtra("mg", p.getInt("mg", 100) / 100f).putExtra("gg", p.getInt("gg", 100) / 100f)
            startForegroundService(i); moveTaskToBack(true)
        }
    }
}
